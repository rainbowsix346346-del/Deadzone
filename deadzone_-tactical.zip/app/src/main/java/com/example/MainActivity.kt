package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.GameViewModel
import com.example.ui.Screen
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: GameViewModel = viewModel()
                val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
                val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
                val difficulty by viewModel.difficulty.collectAsStateWithLifecycle()
                val sensitivity by viewModel.controlSensitivity.collectAsStateWithLifecycle()
                val playerProfile by viewModel.playerProfile.collectAsStateWithLifecycle()
                val topScores by viewModel.topScores.collectAsStateWithLifecycle()
                val gameState by viewModel.gameState.collectAsStateWithLifecycle()

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    // innerPadding is ignored for full immersive gameplay layouts
                    _unused(innerPadding)
                    
                    when (currentScreen) {
                        Screen.SPLASH -> {
                            SplashScreen(
                                language = selectedLanguage,
                                onNavigateToMenu = { viewModel.navigateTo(Screen.MENU) }
                            )
                        }
                        Screen.MENU -> {
                            MenuScreen(
                                language = selectedLanguage,
                                onNavigate = { viewModel.navigateTo(it) },
                                onStartGame = { viewModel.startNewGame() }
                            )
                        }
                        Screen.LOBBY -> {
                            LobbyScreen(
                                profile = playerProfile,
                                language = selectedLanguage,
                                onBack = { viewModel.navigateTo(Screen.MENU) },
                                onEquipSkin = { viewModel.equipSkin(it) },
                                onBuySkin = { name, cost -> viewModel.buySkin(name, cost) },
                                onUpgradeSkill = { type, cost -> viewModel.upgradeSkill(type, cost) },
                                onUpdateIgn = { newName -> viewModel.updateIgn(newName) }
                            )
                        }
                        Screen.SETTINGS -> {
                            SettingsScreen(
                                currentLanguage = selectedLanguage,
                                currentDifficulty = difficulty,
                                currentSensitivity = sensitivity,
                                onBack = { viewModel.navigateTo(Screen.MENU) },
                                onLanguageChange = { viewModel.setLanguage(it) },
                                onDifficultyChange = { viewModel.setDifficulty(it) },
                                onSensitivityChange = { viewModel.setSensitivity(it) }
                            )
                        }
                        Screen.LEADERBOARD -> {
                            LeaderboardScreen(
                                topScores = topScores,
                                language = selectedLanguage,
                                onBack = { viewModel.navigateTo(Screen.MENU) },
                                onReportCheat = { id -> viewModel.reportCheating(id) }
                            )
                        }
                        Screen.IAP -> {
                            IapScreen(
                                language = selectedLanguage,
                                onBack = { viewModel.navigateTo(Screen.MENU) },
                                onPurchaseFinished = { amount -> viewModel.triggerInAppPurchase(amount) }
                            )
                        }
                        Screen.GAME -> {
                            GameScreen(
                                session = gameState,
                                language = selectedLanguage,
                                sensitivity = sensitivity,
                                onBackToLobby = { viewModel.navigateTo(Screen.MENU) },
                                onGameResult = { kills, score, cashEarned ->
                                    viewModel.submitGameResult(kills, score, cashEarned)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

// Suppress unused content warnings cleanly
private fun _unused(any: Any) {}
