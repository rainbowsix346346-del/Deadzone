package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.GameLanguage
import com.example.data.Localization
import com.example.ui.Screen
import com.example.ui.theme.DeadzonePrimary
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    language: GameLanguage,
    onNavigateToMenu: () -> Unit
) {
    var startAnimation by remember { mutableStateOf(false) }

    val alphaAnim by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = tween(durationMillis = 1500, easing = LinearOutSlowInEasing),
        label = "alpha"
    )

    val scaleAnim by animateFloatAsState(
        targetValue = if (startAnimation) 1.05f else 0.95f,
        animationSpec = tween(durationMillis = 2200, easing = EaseOutBack),
        label = "scale"
    )

    LaunchedEffect(key1 = true) {
        startAnimation = true
        delay(3200) // Auto-transition splash
        onNavigateToMenu()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable { onNavigateToMenu() } // skip splash on click
            .testTag("splash_screen_container")
    ) {
        // Fallback or background generated art
        Image(
            painter = painterResource(id = R.drawable.img_zombie_splash),
            contentDescription = "Zombie Splash Screen Banner",
            modifier = Modifier
                .fillMaxSize()
                .scale(scaleAnim)
                .alpha(alphaAnim * 0.45f),
            contentScale = ContentScale.Crop
        )

        // Vignette or Ambient Glow overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    androidx.compose.ui.graphics.Brush.verticalGradient(
                        colors = listOf(Color(0xFF0A0202), Color(0xFF000000))
                    )
                )
        )

        // Centered details matching the screenshot perfectly
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxWidth()
                .padding(24.dp)
                .alpha(alphaAnim),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // 1. White glowing skull icon on top
            Text(
                text = "💀",
                fontSize = 110.sp,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // 2. Large red title: "COD ZOMBIES 2D"
            Text(
                text = Localization.get("menu_title", language),
                fontSize = 46.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFE53935), // Vibrant red matching screenshot
                letterSpacing = 2.sp,
                modifier = Modifier.testTag("splash_title_text")
            )

            Spacer(modifier = Modifier.height(12.dp))

            // 3. Subtitle: "بقا در دنیای مردگان متحرک"
            Text(
                text = Localization.get("menu_subtitle", language),
                fontSize = 18.sp,
                color = Color.White.copy(alpha = 0.85f),
                fontWeight = FontWeight.Medium,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(100.dp))

            // 4. Bold prominent creator name: "ساخته شده توسط حسین حمیدی"
            Column(
                modifier = Modifier.testTag("splash_madeby_container"),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = Localization.get("splash_madeby", language),
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White.copy(alpha = 0.65f),
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "SURVIVAL HORROR SIMULATION v1.2",
                    fontSize = 10.sp,
                    color = Color.White.copy(alpha = 0.3f),
                    letterSpacing = 2.sp
                )
            }
        }
    }
}
