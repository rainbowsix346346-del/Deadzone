package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

enum class Screen {
    SPLASH,
    MENU,
    LOBBY,
    GAME,
    SETTINGS,
    LEADERBOARD,
    IAP
}

enum class GameDifficulty {
    EASY, MEDIUM, HARD, NIGHTMARE
}

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val db = AppDatabase.getDatabase(application)
    val repository = GameRepository(db)

    // State
    private val _currentScreen = MutableStateFlow(Screen.SPLASH)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _selectedLanguage = MutableStateFlow(GameLanguage.PERSIAN)
    val selectedLanguage: StateFlow<GameLanguage> = _selectedLanguage.asStateFlow()

    private val _difficulty = MutableStateFlow(GameDifficulty.MEDIUM)
    val difficulty: StateFlow<GameDifficulty> = _difficulty.asStateFlow()

    private val _controlSensitivity = MutableStateFlow(1.0f)
    val controlSensitivity: StateFlow<Float> = _controlSensitivity.asStateFlow()

    val playerProfile: StateFlow<PlayerProfile?> = repository.playerProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val topScores: StateFlow<List<LeaderboardEntry>> = repository.topScores
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Game Session states
    private val _gameState = MutableStateFlow<GameSessionState?>(null)
    val gameState: StateFlow<GameSessionState?> = _gameState.asStateFlow()

    init {
        viewModelScope.launch {
            repository.ensureProfileExists()
        }
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun setLanguage(lang: GameLanguage) {
        _selectedLanguage.value = lang
    }

    fun setDifficulty(diff: GameDifficulty) {
        _difficulty.value = diff
    }

    fun setSensitivity(sens: Float) {
        _controlSensitivity.value = sens
    }

    fun updateIgn(newName: String) {
        viewModelScope.launch {
            val current = playerProfile.value ?: return@launch
            if (newName.isNotBlank()) {
                repository.updateProfile(current.copy(ign = newName))
            }
        }
    }

    fun buySkin(skinName: String, cost: Int): Boolean {
        val current = playerProfile.value ?: return false
        if (current.cash >= cost) {
            val updatedSkins = if (current.unlockedSkins.split(",").contains(skinName)) {
                current.unlockedSkins
            } else {
                "${current.unlockedSkins},$skinName"
            }
            viewModelScope.launch {
                repository.updateProfile(
                    current.copy(
                        cash = current.cash - cost,
                        unlockedSkins = updatedSkins,
                        selectedSkin = skinName
                    )
                )
            }
            return true
        }
        return false
    }

    fun equipSkin(skinName: String) {
        val current = playerProfile.value ?: return
        if (current.unlockedSkins.split(",").contains(skinName)) {
            viewModelScope.launch {
                repository.updateProfile(current.copy(selectedSkin = skinName))
            }
        }
    }

    fun upgradeSkill(type: String, cost: Int): Boolean {
        val current = playerProfile.value ?: return false
        if (current.cash >= cost) {
            val updated = when (type) {
                "reload" -> {
                    if (current.reloadSkillLevel < 5) current.copy(
                        cash = current.cash - cost,
                        reloadSkillLevel = current.reloadSkillLevel + 1
                    ) else null
                }
                "stealth" -> {
                    if (current.stealthSkillLevel < 5) current.copy(
                        cash = current.cash - cost,
                        stealthSkillLevel = current.stealthSkillLevel + 1
                    ) else null
                }
                "battery" -> {
                    if (current.batterySkillLevel < 5) current.copy(
                        cash = current.cash - cost,
                        batterySkillLevel = current.batterySkillLevel + 1
                    ) else null
                }
                else -> null
            }

            if (updated != null) {
                viewModelScope.launch {
                    repository.updateProfile(updated)
                }
                return true
            }
        }
        return false
    }

    fun triggerInAppPurchase(amount: Int) {
        viewModelScope.launch {
            val current = playerProfile.value ?: return@launch
            repository.updateProfile(current.copy(cash = current.cash + amount))
        }
    }

    // Game execution controls
    fun startNewGame() {
        val profile = playerProfile.value
        val speedMultiplier = when (_difficulty.value) {
            GameDifficulty.EASY -> 0.7f
            GameDifficulty.MEDIUM -> 1.0f
            GameDifficulty.HARD -> 1.3f
            GameDifficulty.NIGHTMARE -> 1.8f
        }
        val batteryDampening = 1.0f + (profile?.batterySkillLevel ?: 0) * 0.15f // Extended battery life skill
        val stealthMultiplier = 1.0f - (profile?.stealthSkillLevel ?: 0) * 0.12f // Quiet movement skill
        val reloadTimeReduction = (profile?.reloadSkillLevel ?: 0) * 0.15f // Reload upgrade advantage

        _gameState.value = GameSessionState(
            difficulty = _difficulty.value,
            zombieSpeedMultiplier = speedMultiplier,
            batteryBurnRate = 0.05f / batteryDampening,
            noiseMuffling = stealthMultiplier,
            reloadTimeDiscount = reloadTimeReduction,
            skinName = profile?.selectedSkin ?: "Stealth Recon"
        ).apply {
            spawnInitialEntities()
        }
        navigateTo(Screen.GAME)
    }

    fun submitGameResult(kills: Int, score: Int, moneyEarned: Int) {
        val profile = playerProfile.value ?: return
        viewModelScope.launch {
            val updatedGamesPlayed = profile.gamesPlayed + 1
            val updatedKills = profile.totalKills + kills
            val updatedCash = profile.cash + moneyEarned
            val updatedHighScore = if (score > profile.highScore) score else profile.highScore
            repository.updateProfile(
                profile.copy(
                    gamesPlayed = updatedGamesPlayed,
                    totalKills = updatedKills,
                    cash = updatedCash,
                    highScore = updatedHighScore
                )
            )
            repository.submitScore(profile.uid, profile.ign, score)
        }
    }

    fun reportCheating(id: Int) {
        viewModelScope.launch {
            repository.reportCheat(id)
        }
    }
}

// Represent local live game state
data class Zombie(
    var id: Int,
    var x: Float,
    var y: Float,
    var vx: Float = 0f,
    var vy: Float = 0f,
    var health: Float = 100f,
    var speed: Float = 2.5f,
    var state: String = "WANDER", // WANDER, CHASE, INVESTIGATING
    var targetX: Float = 0f,
    var targetY: Float = 0f,
    var wanderTimer: Int = 0,
    var isAlerted: Boolean = false
)

data class BatteryPickup(
    val x: Float,
    val y: Float,
    var isCollected: Boolean = false
)

data class BloodSplat(
    val x: Float,
    val y: Float,
    val size: Float,
    val isPool: Boolean = false
)

data class SoundBlast(
    val x: Float,
    val y: Float,
    val radius: Float,
    val timer: Int = 15 // Decay timer frames
)

data class GameSessionState(
    val difficulty: GameDifficulty,
    val zombieSpeedMultiplier: Float,
    val batteryBurnRate: Float,
    val noiseMuffling: Float,
    val reloadTimeDiscount: Float,
    val skinName: String
) {
    var playerX = 400f
    var playerY = 600f
    var playerAngle = 0f // Degrees
    var playerHealth = 100f
    var stamina = 100f
    var flashlightBattery = 100f
    var flashlightOn = true
    var currentWeapon = "Pistol" // Pistol, Shotgun, Rifle
    var ammo = 12
    var score = 0
    var cashEarned = 0
    var currentWave = 1
    var isGameOver = false
    var isVictory = false

    var powerGeneratorRepaired = false
    var doorBarricadeCleared = false
    var exitGateOpened = false

    val zombies = mutableListOf<Zombie>()
    val batteries = mutableListOf<BatteryPickup>()
    val bullets = mutableListOf<Bullet>()
    val bloodSplats = mutableListOf<BloodSplat>()
    var soundBlast: SoundBlast? = null
    var screenShakeAmount = 0f

    // Dimensions of the 2D arena game layout map
    val mapWidth = 2000f
    val mapHeight = 1600f

    // Gate & Puzzle positions
    val generatorX = 1400f
    val generatorY = 200f
    val gateX = 1800f
    val gateY = 1400f
    val barricadeX = 1000f
    val barricadeY = 800f
    val buyStationX = 800f
    val buyStationY = 500f

    fun spawnInitialEntities() {
        // Spawn scattered batteries
        for (i in 1..8) {
            batteries.add(
                BatteryPickup(
                    x = Random.nextFloat() * (mapWidth - 100f) + 50f,
                    y = Random.nextFloat() * (mapHeight - 100f) + 50f
                )
            )
        }

        // Spawn zombies scattered
        for (i in 1..15) {
            zombies.add(
                Zombie(
                    id = i,
                    x = Random.nextFloat() * (mapWidth - 800f) + 600f, // Spare safe spawn around player
                    y = Random.nextFloat() * (mapHeight - 400f) + 200f,
                    speed = (1.5f + Random.nextFloat() * 1.5f) * zombieSpeedMultiplier
                )
            )
        }
    }

    fun makeNoise(x: Float, y: Float, baseRadius: Float) {
        val finalRadius = baseRadius * noiseMuffling
        soundBlast = SoundBlast(x, y, finalRadius)
        
        // Alert zombie sensory arrays in earshot
        for (z in zombies) {
            val dist = calculateDistance(z.x, z.y, x, y)
            if (dist <= finalRadius) {
                z.state = "CHASE"
                z.targetX = playerX
                z.targetY = playerY
                z.isAlerted = true
                z.wanderTimer = 180 // Aggro timer frames
            }
        }
    }
}

data class Bullet(
    var x: Float,
    var y: Float,
    val vx: Float,
    val vy: Float,
    val damage: Float,
    var active: Boolean = true,
    val isRocket: Boolean = false
)

fun calculateDistance(x1: Float, y1: Float, x2: Float, y2: Float): Float {
    return kotlin.math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2))
}
