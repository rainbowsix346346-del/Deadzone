package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameLanguage
import com.example.data.LeaderboardEntry
import com.example.data.Localization
import com.example.ui.Screen
import com.example.ui.theme.DeadzoneAccent
import com.example.ui.theme.DeadzonePrimary
import com.example.ui.theme.DeadzoneSurface
import com.example.ui.theme.DeadzoneTertiary

@Composable
fun LeaderboardScreen(
    topScores: List<LeaderboardEntry>,
    language: GameLanguage,
    onBack: () -> Unit,
    onReportCheat: (Int) -> Unit
) {
    Scaffold(
        topBar = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Black)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { onBack() }.testTag("leaderboard_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Return to menu",
                        tint = DeadzonePrimary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "BACK",
                        color = DeadzonePrimary,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                }

                Text(
                    text = Localization.get("leaderboard_title", language).uppercase(),
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 3.sp,
                    modifier = Modifier.align(Alignment.Center)
                )
            }
        },
        containerColor = Color.Black
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            // Anti-cheat instruction panel
            Surface(
                color = DeadzoneAccent.copy(alpha = 0.08f),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DeadzoneAccent.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "info",
                        tint = DeadzoneAccent,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "VIGILANCE DIRECTIVE: Our client-side heuristic engine screens for anomalous score injections (e.g., scores > 500k). If you suspect a player has modded data, report them below. Admin panel logs auto-quarantine users facing 2+ visual flagging records.",
                        fontSize = 11.sp,
                        color = Color.White.copy(alpha = 0.85f),
                        lineHeight = 15.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Leaderboard Headers
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DeadzoneSurface)
                    .border(1.dp, Color.DarkGray)
                    .padding(vertical = 10.dp, horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = Localization.get("leaderboard_ign", language).uppercase(),
                    color = Color.LightGray,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1.5f)
                )
                Text(
                    text = Localization.get("leaderboard_uid", language).uppercase(),
                    color = Color.LightGray,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1.2f),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                Text(
                    text = Localization.get("leaderboard_score", language).uppercase(),
                    color = Color.LightGray,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1.2f)
                )
                Text(
                    text = "ACTION FLAGGING",
                    color = Color.LightGray,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1.5f)
                )
            }

            // Scores rows
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, Color.DarkGray)
                    .background(Color.Black),
                verticalArrangement = Arrangement.spacedBy(1.dp)
            ) {
                items(topScores) { entry ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(if (entry.isFlagged) DeadzoneTertiary.copy(alpha = 0.05f) else DeadzoneSurface.copy(alpha = 0.3f))
                            .padding(vertical = 12.dp, horizontal = 12.dp)
                            .testTag("leaderboard_row_${entry.id}"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // IGN Columns
                        Text(
                            text = entry.ign,
                            color = if (entry.isFlagged) Color.Gray else Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1.5f)
                        )

                        // UID
                        Text(
                            text = "#${entry.uid}",
                            color = Color.Gray,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1.2f)
                        )

                        // Score
                        Text(
                            text = if (entry.isFlagged) "0" else "${entry.score} PTS",
                            color = if (entry.isFlagged) Color.Gray else DeadzonePrimary,
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            modifier = Modifier.weight(1.2f)
                        )

                        // Reporting / Status
                        Box(modifier = Modifier.weight(1.5f), contentAlignment = Alignment.CenterStart) {
                            if (entry.isFlagged) {
                                Surface(
                                    color = DeadzoneTertiary.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.border(1.dp, DeadzoneTertiary, RoundedCornerShape(4.dp))
                                ) {
                                    Text(
                                        text = Localization.get("leaderboard_flagged", language),
                                        color = DeadzoneTertiary,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            } else {
                                Button(
                                    onClick = { onReportCheat(entry.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = DeadzoneTertiary),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier
                                        .height(28.dp)
                                        .testTag("report_btn_${entry.id}")
                                ) {
                                    Text(
                                        text = if (entry.reportCount > 0) "REPORTED (${entry.reportCount})" else Localization.get("leaderboard_report", language),
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
