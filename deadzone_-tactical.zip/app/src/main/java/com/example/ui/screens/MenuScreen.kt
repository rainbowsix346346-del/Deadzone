package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.GameLanguage
import com.example.data.Localization
import com.example.ui.Screen
import com.example.ui.theme.DeadzonePrimary
import com.example.ui.theme.DeadzoneSurface

@Composable
fun MenuScreen(
    language: GameLanguage,
    onNavigate: (Screen) -> Unit,
    onStartGame: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("menu_screen_container")
    ) {
        // Aesthetic Background image
        Image(
            painter = painterResource(id = R.drawable.img_zombie_splash),
            contentDescription = "Atmospheric Zombie Battle Zone",
            modifier = Modifier
                .fillMaxSize()
                .alpha(0.35f),
            contentScale = ContentScale.Crop
        )

        // Radial shadow vignette overlay
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    androidx.compose.ui.graphics.Brush.radialGradient(
                        colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.9f)),
                        radius = 1100f
                    )
                )
        )

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left Column: Branding, App title, Subtitle, Developer Name
            Column(
                modifier = Modifier
                    .weight(1.2f)
                    .padding(end = 24.dp)
            ) {
                Surface(
                    color = Color.Red.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.border(1.dp, Color.Red.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                ) {
                    Text(
                        text = "ALERT LEVEL: HAZARDOUS",
                        color = Color.Red,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = Localization.get("menu_title", language),
                    fontSize = 52.sp,
                    fontWeight = FontWeight.Black,
                    color = DeadzonePrimary,
                    letterSpacing = 8.sp,
                    modifier = Modifier.testTag("menu_title_text")
                )

                Text(
                    text = Localization.get("menu_subtitle", language),
                    fontSize = 15.sp,
                    color = Color.White.copy(alpha = 0.8f),
                    fontWeight = FontWeight.Normal,
                    letterSpacing = 2.sp
                )

                Spacer(modifier = Modifier.height(24.dp))

                // Mandatory Developer Credits Display
                Card(
                    colors = CardDefaults.cardColors(containerColor = DeadzoneSurface.copy(alpha = 0.85f)),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .border(1.dp, DeadzonePrimary.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                        .testTag("menu_creator_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = Localization.get("menu_dev", language),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Engine Architecture: Kotlin & Jetpack Compose Native Canvas Game Loop",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.5f)
                        )
                    }
                }
            }

            // Right Column: Navigation and play Actions
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.End
            ) {
                // Play Button (Primary Launch action)
                TacticalMenuButton(
                    text = Localization.get("menu_play", language),
                    icon = Icons.Default.PlayArrow,
                    highlighted = true,
                    testTag = "btn_start_game",
                    onClick = { onStartGame() }
                )

                Spacer(modifier = Modifier.height(10.dp))

                TacticalMenuButton(
                    text = Localization.get("menu_lobby", language),
                    icon = Icons.Default.Person,
                    testTag = "btn_nav_lobby",
                    onClick = { onNavigate(Screen.LOBBY) }
                )

                Spacer(modifier = Modifier.height(10.dp))

                TacticalMenuButton(
                    text = Localization.get("menu_leaderboard", language),
                    icon = Icons.Default.Star,
                    testTag = "btn_nav_leaderboard",
                    onClick = { onNavigate(Screen.LEADERBOARD) }
                )

                Spacer(modifier = Modifier.height(10.dp))

                TacticalMenuButton(
                    text = Localization.get("menu_store", language),
                    icon = Icons.Default.ShoppingCart,
                    testTag = "btn_nav_iap",
                    onClick = { onNavigate(Screen.IAP) }
                )

                Spacer(modifier = Modifier.height(10.dp))

                TacticalMenuButton(
                    text = Localization.get("menu_settings", language),
                    icon = Icons.Default.Settings,
                    testTag = "btn_nav_settings",
                    onClick = { onNavigate(Screen.SETTINGS) }
                )
            }
        }
    }
}

@Composable
fun TacticalMenuButton(
    text: String,
    icon: ImageVector,
    highlighted: Boolean = false,
    testTag: String,
    onClick: () -> Unit
) {
    val containerColor = if (highlighted) DeadzonePrimary else DeadzoneSurface
    val contentColor = if (highlighted) Color.Black else Color.White
    val borderStrokeColor = if (highlighted) Color.White else DeadzonePrimary.copy(alpha = 0.35f)

    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier
            .fillMaxWidth(0.9f)
            .height(50.dp)
            .border(2.dp, borderStrokeColor, RoundedCornerShape(6.dp))
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = text.uppercase(),
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 2.sp
            )
            Icon(
                imageVector = icon,
                contentDescription = "Menu icon pointer",
                tint = contentColor,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
