package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.GameLanguage
import com.example.data.Localization
import com.example.ui.*
import com.example.ui.theme.DeadzoneAccent
import com.example.ui.theme.DeadzonePrimary
import com.example.ui.theme.DeadzoneSurface
import com.example.ui.theme.DeadzoneTertiary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.*
import kotlin.random.Random

data class ExplosiveBlast(
    val x: Float,
    val y: Float,
    val initialRadius: Float,
    val maxRadius: Float,
    var currentRadius: Float,
    var framesLeft: Int = 20
)

data class GasTrap(val x: Float, val y: Float, val maxRadius: Float = 140f, var timer: Int = 300)
data class FreezeTrap(val x: Float, val y: Float, val maxRadius: Float = 120f, var timer: Int = 240)
data class DecoyTrap(val x: Float, val y: Float, var timer: Int = 360, val id: Int = Random.nextInt())
data class LandmineTrap(val x: Float, val y: Float, val id: Int = Random.nextInt())

@Composable
fun GameScreen(
    session: GameSessionState?,
    language: GameLanguage,
    sensitivity: Float,
    onBackToLobby: () -> Unit,
    onGameResult: (Int, Int, Int) -> Unit // kills, score, cashEarned
) {
    if (session == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = DeadzonePrimary)
        }
        return
    }
    val session = session

    val coroutineScope = rememberCoroutineScope()
    var frameTick by remember { mutableStateOf(0L) }
    var runningMode by remember { mutableStateOf(true) } // default to RUN mode for swift survival
    var isShoppingOpened by remember { mutableStateOf(false) }
    var gameMessage by remember { mutableStateOf<String?>("به بازی زنده ماندن حسین حمیدی خوش آمدید!") }
    
    // Joystick Offsets
    var joystickOffsetX by remember { mutableStateOf(0f) }
    var joystickOffsetY by remember { mutableStateOf(0f) }
    
    // Progressive Locks
    var door2Unlocked by remember { mutableStateOf(false) }
    
    // Jet Airstrike Support
    var airstrikeActive by remember { mutableStateOf(false) }
    var airstrikeJetX by remember { mutableStateOf(-300f) }
    var airstrikeJetY by remember { mutableStateOf(400f) }
    val explosiveBlasts = remember { mutableStateListOf<com.example.ui.screens.ExplosiveBlast>() }

    // Controls
    var activeMoveX by remember { mutableStateOf(0f) }
    var activeMoveY by remember { mutableStateOf(0f) }
    var activeAimAngle by remember { mutableStateOf(0f) }
    var lastFireTime by remember { mutableStateOf(0L) }
    var isAiming by remember { mutableStateOf(false) }
    var playerTargetX by remember { mutableStateOf<Float?>(null) }
    var playerTargetY by remember { mutableStateOf<Float?>(null) }

    // Crouch state
    var isCrouching by remember { mutableStateOf(false) }

    // 30 Upgrades / Perks / Support states
    var juggernogActive by remember { mutableStateOf(false) } // perk 1
    var speedColaActive by remember { mutableStateOf(false) } // perk 2
    var staminUpActive by remember { mutableStateOf(false) } // perk 3
    var doubleTapActive by remember { mutableStateOf(false) } // perk 4
    var phDlipperActive by remember { mutableStateOf(false) } // perk 5 (blast immunity)
    var magneticCollectorActive by remember { mutableStateOf(false) } // perk 6 (batteries magnet)
    var hasArmorVest by remember { mutableStateOf(false) } // perk 7 (armor protection plates)
    var quickReviveActive by remember { mutableStateOf(false) } // perk 8 (active HP regeneration)
    var cherryShockActive by remember { mutableStateOf(false) } // perk 9 (electric cherry low-reload shock)
    var vitalSerumActive by remember { mutableStateOf(false) } // perk 10 (infinite or 10x battery duration)
    var deadshotActive by remember { mutableStateOf(false) } // perk 11 (bullet pierce double penetrations)
    var muleKickActive by remember { mutableStateOf(false) } // perk 12 (+200 max bullet capacity limit)

    // Usable Consumables in game State counts (available for purchase in shop)
    var grenadesCount by remember { mutableStateOf(3) } // item 13
    var freezeTrapsCount by remember { mutableStateOf(1) } // item 14
    var decoysCount by remember { mutableStateOf(1) } // item 15
    var landminesCount by remember { mutableStateOf(2) } // item 16
    var gasGrenadesCount by remember { mutableStateOf(2) } // item 17

    // Support Tech (Active Deployment triggers)
    var sentryDeployed by remember { mutableStateOf(false) } // item 18
    var sentryX by remember { mutableStateOf(0f) }
    var sentryY by remember { mutableStateOf(0f) }
    var sentryRotateAngle by remember { mutableStateOf(0f) }
    var sentryTicksRemaining by remember { mutableStateOf(0) } // lifetime timer

    var timeWarpRemainingTicks by remember { mutableStateOf(0) } // item 19 (slow zombies down)
    var empStunRemainingTicks by remember { mutableStateOf(0) } // item 20 (stun zombies completely)

    // Active deployment lists on the map for high visual fidelity drawing
    val activeGasTraps = remember { mutableStateListOf<GasTrap>() }
    val activeFreezeTraps = remember { mutableStateListOf<FreezeTrap>() }
    val activeDecoys = remember { mutableStateListOf<DecoyTrap>() }
    val activeLandmines = remember { mutableStateListOf<LandmineTrap>() }

    // Screen Shake Offset
    var shakeX by remember { mutableStateOf(0f) }
    var shakeY by remember { mutableStateOf(0f) }

    // Proximity triggers
    val distToGenerator = calculateDistance(session.playerX, session.playerY, session.generatorX, session.generatorY)
    val distToBarricade = calculateDistance(session.playerX, session.playerY, session.barricadeX, session.barricadeY)
    val distToGate = calculateDistance(session.playerX, session.playerY, session.gateX, session.gateY)
    val distToBuy = calculateDistance(session.playerX, session.playerY, session.buyStationX, session.buyStationY)

    // Trigger Screen Shake Helper
    fun applyIntensityShake() {
        coroutineScope.launch {
            for (i in 1..8) {
                shakeX = (Random.nextFloat() - 0.5f) * 14f
                shakeY = (Random.nextFloat() - 0.5f) * 14f
                delay(20)
            }
            shakeX = 0f
            shakeY = 0f
        }
    }

    // Weapon firing logic with automatic cooldown management
    fun fireActiveWeapon() {
        if (session == null || session.isGameOver || session.isVictory) return
        
        val now = System.currentTimeMillis()
        val cooldown = when (session.currentWeapon) {
            "Rifle" -> 160L
            "Pistol" -> 350L
            "Shotgun" -> 850L
            "RPG" -> 1500L
            else -> 2000L
        }
        if (now - lastFireTime < cooldown) return // COOLDOWN LOCKED

        if (session.ammo <= 0) {
            gameMessage = "خارج از مهمات! برای خرید به ایستگاه خرید (SHOP) مراجعه کنید."
            return
        }

        lastFireTime = now
        session.ammo -= 1
        val angleRad = Math.toRadians(activeAimAngle.toDouble())
        val baseSpeed = 16f
        val damage = if (session.skinName == "Cyber Commando") 45f else 35f

        // Noise Blast
        session.makeNoise(session.playerX, session.playerY, 500f)
        applyIntensityShake()

        when (session.currentWeapon) {
            "Shotgun" -> {
                // Three pellet spray
                for (offset in listOf(-12.0, 0.0, 12.0)) {
                    val sprayRad = Math.toRadians(activeAimAngle.toDouble() + offset)
                    session.bullets.add(
                        Bullet(
                            x = session.playerX,
                            y = session.playerY,
                            vx = (cos(sprayRad) * baseSpeed).toFloat(),
                            vy = (sin(sprayRad) * baseSpeed).toFloat(),
                            damage = damage * 0.75f
                        )
                    )
                }
            }
            "RPG" -> {
                // Rocket bullet (has isRocket = true)
                session.bullets.add(
                    Bullet(
                        x = session.playerX,
                        y = session.playerY,
                        vx = (cos(angleRad) * 12f).toFloat(), // rocket travels slightly slower
                        vy = (sin(angleRad) * 12f).toFloat(),
                        damage = damage * 2.5f,
                        isRocket = true
                    )
                )
                gameMessage = "آر پی جی شلیک شد! مراقب انفجار باشید!"
            }
            "Air Support" -> {
                // Trigger supersonic jet flyby bombing
                if (!airstrikeActive) {
                    airstrikeActive = true
                    airstrikeJetX = -300f
                    airstrikeJetY = session.playerY
                    gameMessage = "پشتیبانی هوایی جنگنده فراخوانده شد! بمباران منطقه قفل شد!"
                } else {
                    gameMessage = "پشتیبانی هوایی در حال حاضر در منطقه فعال است!"
                    session.ammo += 1 // refund ammo
                }
            }
            else -> {
                // Rifle / Pistol direct shot
                session.bullets.add(
                    Bullet(
                        x = session.playerX,
                        y = session.playerY,
                        vx = (cos(angleRad) * baseSpeed).toFloat(),
                        vy = (sin(angleRad) * baseSpeed).toFloat(),
                        damage = if (session.currentWeapon == "Rifle") damage * 1.30f else damage
                    )
                )
            }
        }
    }

    // Game loop clock (runs every ~16ms)
    LaunchedEffect(key1 = session) {
        while (session != null && !session.isGameOver && !session.isVictory) {
            delay(16)
            frameTick++

            if (isAiming) {
                fireActiveWeapon()
            }

            // Dynamic screen shake decaying
            session.screenShakeAmount = max(0f, session.screenShakeAmount - 0.5f)

            // 1. Move Player
            val moveSpeed = if (runningMode) {
                if (session.stamina > 5f) {
                    session.stamina = max(0f, session.stamina - 0.5f)
                    5.5f * sensitivity
                } else {
                    2.5f * sensitivity // out of breath
                }
            } else {
                session.stamina = min(100f, session.stamina + 0.3f)
                2.2f * sensitivity // Stealth Crouch Speed
            }

            // Normalizing move vectors
            var finalMoveX = activeMoveX
            var finalMoveY = activeMoveY

            val targetX = playerTargetX
            val targetY = playerTargetY
            if (targetX != null && targetY != null) {
                val dxToTarget = targetX - session.playerX
                val dyToTarget = targetY - session.playerY
                val distToTarget = sqrt(dxToTarget * dxToTarget + dyToTarget * dyToTarget)
                if (distToTarget < 12f) {
                    playerTargetX = null
                    playerTargetY = null
                    activeMoveX = 0f
                    activeMoveY = 0f
                } else {
                    finalMoveX = dxToTarget
                    finalMoveY = dyToTarget
                    // Sync player aiming angle toward tapped destination!
                    val angleRad = atan2(dyToTarget.toDouble(), dxToTarget.toDouble())
                    session.playerAngle = Math.toDegrees(angleRad).toFloat()
                }
            }

            val magnitude = sqrt(finalMoveX * finalMoveX + finalMoveY * finalMoveY)
            if (magnitude > 0.05f) {
                val dx = (finalMoveX / magnitude) * moveSpeed
                val dy = (finalMoveY / magnitude) * moveSpeed
                
                // Keep inside map bounds
                val nextX = session.playerX + dx
                val nextY = session.playerY + dy

                // Enforce progressive room unlocking walls
                var canWalk = true
                if (!session.doorBarricadeCleared && nextX > 900f) {
                    canWalk = false
                    if (frameTick % 50 == 0L) {
                        gameMessage = "درب خانه باغچه قفل است! باز کردن با ۵۰۰ سکه"
                    }
                } else if (!door2Unlocked && nextX > 1450f) {
                    canWalk = false
                    if (frameTick % 50 == 0L) {
                        gameMessage = "درب بخش ژنراتور قفل است! باز کردن با ۱۵۰۰ سکه"
                    }
                }

                if (canWalk) {
                    val nextDistToBarricade = calculateDistance(nextX, nextY, session.barricadeX, session.barricadeY)
                    if (session.doorBarricadeCleared || nextDistToBarricade > 90f) {
                        if (nextX in 50f..session.mapWidth - 50f) session.playerX = nextX
                        if (nextY in 50f..session.mapHeight - 50f) session.playerY = nextY
                    } else {
                        playerTargetX = null
                        playerTargetY = null
                    }
                } else {
                    playerTargetX = null
                    playerTargetY = null
                }

                // Make footsteps sound waves
                if (runningMode) {
                    if (frameTick % 12 == 0L) {
                        session.makeNoise(session.playerX, session.playerY, 280f)
                    }
                } else {
                    // crouching footstep makes tiny sounds
                    if (frameTick % 25 == 0L) {
                        session.makeNoise(session.playerX, session.playerY, 80f)
                    }
                }
            }

            // Recovery standing on Persian Carpet
            val distToCarpet = calculateDistance(session.playerX, session.playerY, 500f, 600f)
            if (distToCarpet < 160f) {
                session.stamina = min(100f, session.stamina + 0.6f)
                if (frameTick % 40 == 0L) {
                    session.playerHealth = min(100f, session.playerHealth + 1.5f)
                    gameMessage = "آرامش و سلامتی از تار و پود فرش ایرانی!"
                }
            }

            // 2. Battery drainage
            if (session.flashlightOn) {
                session.flashlightBattery = max(0f, session.flashlightBattery - session.batteryBurnRate)
            }

            // 3. Bullets flight & Hit detection
            val bulletIter = session.bullets.iterator()
            while (bulletIter.hasNext()) {
                val b = bulletIter.next()
                b.x += b.vx
                b.y += b.vy

                // Out of boundaries check
                if (b.x < 0 || b.x > session.mapWidth || b.y < 0 || b.y > session.mapHeight) {
                    b.active = false
                } else {
                    // Check zombie intersections
                    for (z in session.zombies) {
                        if (z.health > 0) {
                            val dist = calculateDistance(b.x, b.y, z.x, z.y)
                            if (dist < 32f) {
                                z.health -= b.damage
                                z.state = "CHASE" // immediately alerts
                                z.targetX = session.playerX
                                z.targetY = session.playerY
                                b.active = false
                                session.score += 50
                                
                                // Spawn a small blood hit splatter
                                session.bloodSplats.add(com.example.ui.BloodSplat(
                                    x = z.x + (Math.random() * 16 - 8).toFloat(),
                                    y = z.y + (Math.random() * 16 - 8).toFloat(),
                                    size = (Math.random() * 14 + 10).toFloat(),
                                    isPool = false
                                ))
                                
                                if (z.health <= 0) {
                                    session.score += 200
                                    session.cashEarned += 25
                                    gameMessage = "شکار زامبی موفق! +۲۵ سکه"
                                    
                                    // Spawn a massive blood puddle pool and multiple spray marks
                                    session.bloodSplats.add(com.example.ui.BloodSplat(
                                        x = z.x,
                                        y = z.y,
                                        size = (Math.random() * 18 + 42).toFloat(),
                                        isPool = true
                                    ))
                                    for (i in 1..5) {
                                        val ox = (Math.random() * 50 - 25).toFloat()
                                        val oy = (Math.random() * 50 - 25).toFloat()
                                        session.bloodSplats.add(com.example.ui.BloodSplat(
                                            x = z.x + ox,
                                            y = z.y + oy,
                                            size = (Math.random() * 16 + 8).toFloat(),
                                            isPool = false
                                        ))
                                    }
                                }
                                break
                            }
                        }
                    }
                }

                if (!b.active) {
                    if (b.isRocket) {
                        val expX = b.x
                        val expY = b.y
                        // Explosive splash damage (within 240 radius)
                        for (z in session.zombies) {
                            if (z.health > 0) {
                                val rDist = calculateDistance(expX, expY, z.x, z.y)
                                if (rDist <= 240f) {
                                    z.health -= 180f
                                    z.state = "CHASE"
                                    z.targetX = session.playerX
                                    z.targetY = session.playerY
                                    if (z.health <= 0) {
                                        session.score += 200
                                        session.cashEarned += 25
                                    }
                                }
                            }
                        }
                        session.makeNoise(expX, expY, 800f)
                        explosiveBlasts.add(
                            com.example.ui.screens.ExplosiveBlast(
                                x = expX,
                                y = expY,
                                initialRadius = 15f,
                                maxRadius = 220f,
                                currentRadius = 15f,
                                framesLeft = 25
                            )
                        )
                    }
                    bulletIter.remove()
                }
            }

            // 3b. Jet Fighter Airstrike Tick
            if (airstrikeActive) {
                airstrikeJetX += 28f
                if (frameTick % 16 == 0L && airstrikeJetX in 100f..session.mapWidth) {
                    val dropX = airstrikeJetX
                    val dropY = airstrikeJetY + (Random.nextFloat() * 180f - 90f)
                    for (z in session.zombies) {
                        if (z.health > 0) {
                            val rDist = calculateDistance(dropX, dropY, z.x, z.y)
                            if (rDist <= 300f) {
                                z.health -= 350f
                                z.state = "CHASE"
                                if (z.health <= 0) {
                                    session.score += 200
                                    session.cashEarned += 25
                                }
                            }
                        }
                    }
                    explosiveBlasts.add(
                        com.example.ui.screens.ExplosiveBlast(
                            x = dropX,
                            y = dropY,
                            initialRadius = 25f,
                            maxRadius = 300f,
                            currentRadius = 25f,
                            framesLeft = 30
                        )
                    )
                }
                if (airstrikeJetX > session.mapWidth + 500f) {
                    airstrikeActive = false
                }
            }

            // 3c. Decay explosive shockwaves
            val expBlastIter = explosiveBlasts.iterator()
            while (expBlastIter.hasNext()) {
                val bl = expBlastIter.next()
                bl.framesLeft--
                bl.currentRadius += (bl.maxRadius - bl.initialRadius) / 25f
                if (bl.framesLeft <= 0) {
                    expBlastIter.remove()
                }
            }

            // 3d. Wave based zombie respawning
            val aliveZombies = session.zombies.count { it.health > 0 }
            if (aliveZombies == 0 && !session.isGameOver && !session.isVictory) {
                session.currentWave++
                gameMessage = "موج ${session.currentWave} شروع شد! زامبی‌های خشن‌تری در حال تخریب حصارها هستند!"
                val countToSpawn = 6 + session.currentWave * 4
                for (i in 1..countToSpawn) {
                    val multiplier = if (Random.nextBoolean()) 1f else -1f
                    val rx = session.playerX + (450f + Random.nextFloat() * 700f) * multiplier
                    val ry = session.playerY + (450f + Random.nextFloat() * 700f) * multiplier
                    session.zombies.add(
                        Zombie(
                            id = session.zombies.size + i,
                            x = rx.coerceIn(50f, session.mapWidth - 50f),
                            y = ry.coerceIn(50f, session.mapHeight - 50f),
                            speed = (1.4f + Random.nextFloat() * 1.5f) * session.zombieSpeedMultiplier * (1f + session.currentWave * 0.08f),
                            health = 100f + (session.currentWave - 1) * 15f
                        )
                    )
                }
            }

            // 4. Sound blast dissipation
            val currentBlast = session.soundBlast
            if (currentBlast != null) {
                if (frameTick % 30 == 0L) {
                    session.soundBlast = null
                }
            }

            // 5. Zombie AIs Pathing and Attack Behaviors
            for (z in session.zombies) {
                if (z.health <= 0) continue

                // Check Proximity detection or Flashlight illumination
                val playerDeltaX = session.playerX - z.x
                val playerDeltaY = session.playerY - z.y
                val distToPlayer = sqrt(playerDeltaX * playerDeltaX + playerDeltaY * playerDeltaY)

                var canSeePlayer = false
                if (distToPlayer < 120f) {
                    canSeePlayer = true // very close sensory range
                } else if (session.flashlightOn && session.flashlightBattery > 0f) {
                    // Flashlight cone checks
                    val angleToPlayerRad = atan2(playerDeltaY.toDouble(), playerDeltaX.toDouble())
                    val angleToPlayerDeg = Math.toDegrees(angleToPlayerRad).toFloat()
                    
                    // Normalize relative angles
                    var diffAngle = abs(angleToPlayerDeg - session.playerAngle)
                    if (diffAngle > 180f) diffAngle = 360f - diffAngle

                    if (diffAngle < 40f && distToPlayer < 380f) {
                        canSeePlayer = true // Inside flashlight beam!
                    }
                }

                if (canSeePlayer) {
                    z.state = "CHASE"
                    z.targetX = session.playerX
                    z.targetY = session.playerY
                    z.wanderTimer = 180 // Aggro window frames
                }

                // AI state machine execution
                when (z.state) {
                    "CHASE" -> {
                        // Move directly to player
                        val dx = session.playerX - z.x
                        val dy = session.playerY - z.y
                        val len = sqrt(dx * dx + dy * dy)
                        if (len > 5f) {
                            z.vx = (dx / len) * z.speed
                            z.vy = (dy / len) * z.speed
                            z.x += z.vx
                            z.y += z.vy
                        }

                        // Attack player
                        if (len < 30f) {
                            val damageReductionMultiplier = if (session.skinName == "Hazmat Survivor") 0.75f else 1.0f
                            session.playerHealth = max(0f, session.playerHealth - (1.2f * damageReductionMultiplier))
                            applyIntensityShake()

                            if (session.playerHealth <= 0f) {
                                session.isGameOver = true
                                onGameResult(session.score / 250, session.score, session.cashEarned)
                            }
                        }

                        z.wanderTimer--
                        if (z.wanderTimer <= 0) {
                            z.state = "WANDER"
                        }
                    }
                    else -> {
                        // WANDER State
                        if (z.wanderTimer <= 0) {
                            z.vx = (Random.nextFloat() - 0.5f) * z.speed * 0.8f
                            z.vy = (Random.nextFloat() - 0.5f) * z.speed * 0.8f
                            z.wanderTimer = Random.nextInt(60, 150)
                        }

                        z.x = (z.x + z.vx).coerceIn(50f, session.mapWidth - 50f)
                        z.y = (z.y + z.vy).coerceIn(50f, session.mapHeight - 50f)
                        z.wanderTimer--
                    }
                }
            }

            // 6. Batteries Collection Checking
            for (bat in session.batteries) {
                if (!bat.isCollected) {
                    val dist = calculateDistance(session.playerX, session.playerY, bat.x, bat.y)
                    if (dist < 40f) {
                        bat.isCollected = true
                        session.flashlightBattery = min(100f, session.flashlightBattery + 45f)
                        gameMessage = "LITHIUM CELL INGESTED! BATTERY RESTORED"
                        session.score += 50
                    }
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .offset { IntOffset(shakeX.toInt(), shakeY.toInt()) } // Apply screen shake offset juice!
            .testTag("game_field_container")
    ) {
        val zoom = 1.28f // Orthographic scale factor for zoomed-in tactical gameplay
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures { offset ->
                        val centerX = size.width / 2f
                        val centerY = size.height / 2f
                        playerTargetX = (offset.x - centerX) / zoom + session.playerX
                        playerTargetY = (offset.y - centerY) / zoom + session.playerY
                        gameMessage = "MOVE PROTOCOL LOCKED"
                    }
                }
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        activeMoveX = dragAmount.x
                        activeMoveY = dragAmount.y
                    }
                }
        ) {
            val centerX = size.width / 2f
            val centerY = size.height / 2f

            // Represent Camera relative coordinates centering the player on-screen!
            val camX = (centerX / zoom) - session.playerX
            val camY = (centerY / zoom) - session.playerY

            drawContext.canvas.save()
            drawContext.canvas.translate(centerX, centerY)
            drawContext.canvas.scale(zoom, zoom)
            drawContext.canvas.translate(-centerX, -centerY)

            // --- DRAW OUTDOOR CHECKERBOARD GRASS FIELD FIRST ---
            val tileSize = 80f
            val numX = (session.mapWidth / tileSize).toInt()
            val numY = (session.mapHeight / tileSize).toInt()
            for (i in 0..numX) {
                for (j in 0..numY) {
                    val tileX = i * tileSize
                    val tileY = j * tileSize
                    val isEven = (i + j) % 2 == 0
                    val tileCol = if (isEven) Color(0xFF142E0C) else Color(0xFF1B3B12)
                    
                    drawRect(
                        color = tileCol,
                        topLeft = Offset(tileX + camX, tileY + camY),
                        size = Size(tileSize, tileSize)
                    )
                    
                    // Draw tiny stylized grass details ("v" shapes) inside some tiles
                    if ((i * 3 + j * 7) % 5 == 0) {
                        val gx = tileX + 30f + camX
                        val gy = tileY + 40f + camY
                        drawLine(
                            color = Color(0xFF2E6B1D),
                            start = Offset(gx, gy),
                            end = Offset(gx - 6f, gy - 12f),
                            strokeWidth = 3f
                        )
                        drawLine(
                            color = Color(0xFF2E6B1D),
                            start = Offset(gx, gy),
                            end = Offset(gx + 8f, gy - 14f),
                            strokeWidth = 3f
                        )
                    }
                }
            }

            // --- DRAW THE WALLED COMPOUND (Y: 150f to 1250f) ---
            val wallTopY = 150f
            val wallBotY = 1250f
            val compoundHeight = wallBotY - wallTopY
            
            // Room 1: Cozy Iranian Living Room (X: 100f to 900f) - Dark Chestnut Parquet wood floor style
            drawRect(
                color = Color(0xFF4E342E), // Rich warm dark wood parquet
                topLeft = Offset(100f + camX, wallTopY + camY),
                size = Size(800f, compoundHeight)
            )
            // Parquet lines
            for (px in 150..850 step 100) {
                drawLine(
                    color = Color(0xFF3E2723).copy(alpha = 0.55f),
                    start = Offset(px + camX, wallTopY + camY),
                    end = Offset(px + camX, wallBotY + camY),
                    strokeWidth = 4f
                )
            }

            // Room 2: Rose Garden Greenhouse (X: 900f to 1450f) - Checkerstone paths with potted rose planters
            drawRect(
                color = Color(0xFF263238), // Deep tech greenhouse slab
                topLeft = Offset(900f + camX, wallTopY + camY),
                size = Size(550f, compoundHeight)
            )
            // Light garden grids
            for (gx in 950..1400 step 100) {
                drawLine(
                    color = Color(0xFF37474F).copy(alpha = 0.4f),
                    start = Offset(gx + camX, wallTopY + camY),
                    end = Offset(gx + camX, wallBotY + camY),
                    strokeWidth = 2f
                )
            }
            // Draw rows of blooming rose grids inside Room 2
            for (gx in listOf(1050f, 1200f, 1350f)) {
                for (gy in listOf(300f, 600f, 900f)) {
                    drawCircle(color = Color(0xFFE91E63), radius = 12f, center = Offset(gx + camX, gy + camY))
                    drawCircle(color = Color(0xFFE91E63), radius = 8f, center = Offset(gx - 4f + camX, gy - 4f + camY))
                    drawCircle(color = Color(0xFF2E7D32), radius = 5f, center = Offset(gx - 12f + camX, gy + 6f + camY))
                }
            }

            // Room 3: High-Tech Power Generator Sector (X: 1450f to 1900f) - Dark metallic base plate
            drawRect(
                color = Color(0xFF1E272C), // Heavy charcoal steel metal flooring
                topLeft = Offset(1450f + camX, wallTopY + camY),
                size = Size(450f, compoundHeight)
            )
            // Steel floor tile lines
            for (tx in 1500..1850 step 80) {
                drawLine(
                    color = Color(0xFF37474F),
                    start = Offset(tx + camX, wallTopY + camY),
                    end = Offset(tx + camX, wallBotY + camY),
                    strokeWidth = 3f
                )
            }
            // Hazard slash warning indicators along the threshold line (X = 1450f)
            for (hy in wallTopY.toInt()..wallBotY.toInt() step 60) {
                drawLine(
                    color = Color(0xFFFF9800), // Bright caution orange
                    start = Offset(1450f + camX, hy + camY),
                    end = Offset(1465f + camX, hy + 20f + camY),
                    strokeWidth = 6f
                )
                drawLine(
                    color = Color.Black,
                    start = Offset(1465f + camX, hy + 20f + camY),
                    end = Offset(1480f + camX, hy + 45f + camY),
                    strokeWidth = 6f
                )
            }

            // --- BUILD HEAVY BRICK WALLS AROUND THE HOUSETOP AND HOUSEBOTTOM ---
            // Draw heavy horizontal walls
            drawLine(
                color = Color(0xFF5D4037), // Solid dark timber roof wall beam
                start = Offset(100f + camX, wallTopY + camY),
                end = Offset(1900f + camX, wallTopY + camY),
                strokeWidth = 18f
            )
            drawLine(
                color = Color(0xFF3E2723), // Shadow horizontal edge
                start = Offset(100f + camX, wallTopY + 4f + camY),
                end = Offset(1900f + camX, wallTopY + 4f + camY),
                strokeWidth = 4f
            )
            drawLine(
                color = Color(0xFF5D4037), // Bottom timber wall beam
                start = Offset(100f + camX, wallBotY + camY),
                end = Offset(1900f + camX, wallBotY + camY),
                strokeWidth = 18f
            )

            // Physical Room Boundary Dividers
            // Door 1 frame wall: X = 900f
            drawLine(
                color = Color(0xFF8D6E63), // Heavy wood gate beam
                start = Offset(900f + camX, wallTopY + camY),
                end = Offset(900f + camX, wallBotY + camY),
                strokeWidth = 14f
            )
            // Door 2 frame wall: X = 1450f
            drawLine(
                color = Color(0xFF455A64), // Security steel gate beam
                start = Offset(1450f + camX, wallTopY + camY),
                end = Offset(1450f + camX, wallBotY + camY),
                strokeWidth = 16f
            )

            // Leftmost and Rightmost outer walls enclosing compound
            drawLine(
                color = Color(0xFF5D4037),
                start = Offset(100f + camX, wallTopY + camY),
                end = Offset(100f + camX, wallBotY + camY),
                strokeWidth = 18f
            )
            drawLine(
                color = Color(0xFF5D4037),
                start = Offset(1900f + camX, wallTopY + camY),
                end = Offset(1900f + camX, wallBotY + camY),
                strokeWidth = 18f
            )

            // Draw Area bounds deep leafy forest green border 
            drawRect(
                color = Color(0xFF1B3B12),
                topLeft = Offset(camX, camY),
                size = Size(session.mapWidth, session.mapHeight),
                style = Stroke(width = 16f)
            )

            // Draw Deceased Zombies Persistent Blood Splatters (Vivid & Clear!)
            for (splat in session.bloodSplats) {
                if (splat.isPool) {
                    // Massive puddle pool of blood
                    drawCircle(
                        color = Color(0xFFC62828).copy(alpha = 0.75f), // Rich vivid crimson red
                        radius = splat.size,
                        center = Offset(splat.x + camX, splat.y + camY)
                    )
                    drawCircle(
                        color = Color(0xFFB71C1C),
                        radius = splat.size * 0.65f,
                        center = Offset(splat.x + camX, splat.y + camY)
                    )
                    drawCircle(
                        color = Color(0xFF3E0000).copy(alpha = 0.4f), // Dark dry center
                        radius = splat.size * 0.25f,
                        center = Offset(splat.x + camX, splat.y + camY)
                    )
                } else {
                    // Spray streak marks
                    drawCircle(
                        color = Color(0xFFD32F2F).copy(alpha = 0.85f),
                        radius = splat.size,
                        center = Offset(splat.x + camX, splat.y + camY)
                    )
                }
            }

            // --- DRAW TRADITIONAL PERSIAN/IRANIAN CARPET ("فرش ایرانی") ---
            val carpetX = 500f
            val carpetY = 600f
            val carpetW = 240f
            val carpetH = 340f

            // 1. Draw Carpet Base (Deep Persian Crimson Burgundy Red rectangle)
            drawRect(
                color = Color(0xFF8B0000), // Dark Red / Burgundy
                topLeft = Offset(carpetX - carpetW / 2 + camX, carpetY - carpetH / 2 + camY),
                size = Size(carpetW, carpetH)
            )

            // 2. Draw Fringes at Top and Bottom (Beige/Cream threads)
            val fringeLength = 12f
            val fringeSpacing = 6f
            val fringeCount = (carpetW / fringeSpacing).toInt()
            for (i in 0..fringeCount) {
                val fx = carpetX - carpetW / 2f + i * fringeSpacing
                // Top fringes
                drawLine(
                    color = Color(0xFFF5F5DC), // Beige / Cream
                    start = Offset(fx + camX, carpetY - carpetH / 2 - fringeLength + camY),
                    end = Offset(fx + camX, carpetY - carpetH / 2 + camY),
                    strokeWidth = 2f
                )
                // Bottom fringes
                drawLine(
                    color = Color(0xFFF5F5DC),
                    start = Offset(fx + camX, carpetY + carpetH / 2 + camY),
                    end = Offset(fx + camX, carpetY + carpetH / 2 + fringeLength + camY),
                    strokeWidth = 2f
                )
            }

            // 3. Draw Outer Golden Border with delicate pattern spacing
            drawRect(
                color = Color(0xFFD4AF37), // Metallic Gold
                topLeft = Offset(carpetX - carpetW / 2 + 10f + camX, carpetY - carpetH / 2 + 10f + camY),
                size = Size(carpetW - 20f, carpetH - 20f),
                style = Stroke(width = 6f)
            )

            // 4. Draw Inner Navy Blue Floral Border (Lachak-Toranj Style frame)
            drawRect(
                color = Color(0xFF002244), // Persian Blue / Indigo
                topLeft = Offset(carpetX - carpetW / 2 + 22f + camX, carpetY - carpetH / 2 + 22f + camY),
                size = Size(carpetW - 44f, carpetH - 44f),
                style = Stroke(width = 8f)
            )

            // 5. Draw Corner Ornaments (Golden/Cream Corner Pockets - "Lachak")
            val insetCorner = 24f
            val corners = listOf(
                Offset(carpetX - carpetW / 2 + insetCorner, carpetY - carpetH / 2 + insetCorner), // Top Left
                Offset(carpetX + carpetW / 2 - insetCorner, carpetY - carpetH / 2 + insetCorner), // Top Right
                Offset(carpetX - carpetW / 2 + insetCorner, carpetY + carpetH / 2 - insetCorner), // Bottom Left
                Offset(carpetX + carpetW / 2 - insetCorner, carpetY + carpetH / 2 - insetCorner)  // Bottom Right
            )
            for (c in corners) {
                drawCircle(
                    color = Color(0xFFE5C158),
                    radius = 20f,
                    center = Offset(c.x + camX, c.y + camY),
                    style = Stroke(width = 4f)
                )
                drawCircle(
                    color = Color(0xFFD4AF37),
                    radius = 8f,
                    center = Offset(c.x + camX, c.y + camY)
                )
            }

            // 6. Draw central ornate Medallion ("Toranj")
            drawCircle(
                color = Color(0xFFD4AF37), // Golden outer medallion
                radius = 50f,
                center = Offset(carpetX + camX, carpetY + camY),
                style = Stroke(width = 5f)
            )
            drawCircle(
                color = Color(0xFF003366), // Deep Navy core
                radius = 35f,
                center = Offset(carpetX + camX, carpetY + camY)
            )
            drawCircle(
                color = Color(0xFFF5F5DC), // Cream center
                radius = 16f,
                center = Offset(carpetX + camX, carpetY + camY)
            )
            drawCircle(
                color = Color(0xFFB22222), // Crimson red dot inside
                radius = 7f,
                center = Offset(carpetX + camX, carpetY + camY)
            )

            // Draw floral pattern rays outwards from Toranj center
            for (angle in 0..360 step 30) {
                val rad = Math.toRadians(angle.toDouble())
                drawLine(
                    color = Color(0xFFD4AF37),
                    start = Offset(
                        (carpetX + cos(rad) * 35f).toFloat() + camX,
                        (carpetY + sin(rad) * 35f).toFloat() + camY
                    ),
                    end = Offset(
                        (carpetX + cos(rad) * 70f).toFloat() + camX,
                        (carpetY + sin(rad) * 70f).toFloat() + camY
                    ),
                    strokeWidth = 3f
                )
            }

            // --- DRAW PERSISTENT COZY PERSIAN GARDEN ROSES ("گل‌های رز سرخ باغ ایرانی") ---
            val gardenSpots = listOf(
                Offset(carpetX - 220f, carpetY - 260f), // Top-Left corner
                Offset(carpetX + 220f, carpetY - 260f), // Top-Right corner
                Offset(carpetX - 220f, carpetY + 260f), // Bottom-Left corner
                Offset(carpetX + 220f, carpetY + 260f)  // Bottom-Right corner
            )
            for (spot in gardenSpots) {
                // Large green leaf shrub base
                drawCircle(
                    color = Color(0xFF1B5E20), // Rich forest green foliage
                    radius = 35f,
                    center = Offset(spot.x + camX, spot.y + camY)
                )
                drawCircle(
                    color = Color(0xFF2E7D32),
                    radius = 25f,
                    center = Offset(spot.x + camX, spot.y + camY)
                )
                // Draw multiple blooming bright red roses as miniature circles!
                val petalOffsets = listOf(
                    Offset(0f, 0f),
                    Offset(-14f, -10f),
                    Offset(14f, -10f),
                    Offset(-10f, 15f),
                    Offset(10f, 15f)
                )
                for (p in petalOffsets) {
                    drawCircle(
                        color = Color(0xFFD50000), // Sparkling Persian Red rose
                        radius = 8f,
                        center = Offset(spot.x + p.x + camX, spot.y + p.y + camY)
                    )
                    drawCircle(
                        color = Color(0xFFFF8A80), // Rose highlight
                        radius = 4f,
                        center = Offset(spot.x + p.x + camX, spot.y + p.y + camY)
                    )
                }
            }

            // Draw door barricade blocking route
            if (!session.doorBarricadeCleared) {
                drawRect(
                    color = Color(0xFFD84315),
                    topLeft = Offset(session.barricadeX - 45f + camX, session.barricadeY - 90f + camY),
                    size = Size(90f, 180f)
                )
                // Draw lock icon placeholder
                drawCircle(
                    color = Color.Black,
                    radius = 16f,
                    center = Offset(session.barricadeX + camX, session.barricadeY + camY)
                )
            }

            // Draw power Generator
            drawRect(
                color = if (session.powerGeneratorRepaired) DeadzonePrimary else DeadzoneTertiary,
                topLeft = Offset(session.generatorX - 40f + camX, session.generatorY - 40f + camY),
                size = Size(80f, 80f)
            )

            // Draw security Exit gate
            drawRect(
                color = if (session.exitGateOpened) DeadzonePrimary else Color.Gray,
                topLeft = Offset(session.gateX - 60f + camX, session.gateY - 20f + camY),
                size = Size(120f, 40f),
                style = Stroke(width = 8f)
            )

            // Draw buy Station kiosk
            drawCircle(
                color = DeadzoneAccent,
                radius = 35f,
                center = Offset(session.buyStationX + camX, session.buyStationY + camY)
            )

            // Draw scattered lithium batteries
            for (bat in session.batteries) {
                if (!bat.isCollected) {
                    drawRect(
                        color = Color(0xFF00E676),
                        topLeft = Offset(bat.x - 12f + camX, bat.y - 12f + camY),
                        size = Size(24f, 24f)
                    )
                }
            }

            // Draw Sound noise expand wave
            session.soundBlast?.let { b ->
                drawCircle(
                    color = Color(0xFFFF9100).copy(alpha = 0.28f),
                    radius = b.radius,
                    center = Offset(b.x + camX, b.y + camY),
                    style = Stroke(width = 6f)
                )
            }

            // Draw bullets lasers and rocket projectiles
            for (bul in session.bullets) {
                if (bul.active) {
                    if (bul.isRocket) {
                        // RPG rocket bullet drawing
                        drawCircle(
                            color = Color(0xFFFF5722), // Heavy burning rocket orange
                            radius = 12f,
                            center = Offset(bul.x + camX, bul.y + camY)
                        )
                        drawLine(
                            color = Color(0xFFFFFF00), // Sparkling smoke trail
                            start = Offset(bul.x + camX, bul.y + camY),
                            end = Offset(bul.x - bul.vx * 1.8f + camX, bul.y - bul.vy * 1.8f + camY),
                            strokeWidth = 8f
                        )
                        drawCircle(
                            color = Color.White,
                            radius = 4f,
                            center = Offset(bul.x + camX, bul.y + camY)
                        )
                    } else {
                        drawLine(
                            color = Color(0xFFFFEE58),
                            start = Offset(bul.x + camX, bul.y + camY),
                            end = Offset(bul.x - bul.vx * 1.5f + camX, bul.y - bul.vy * 1.5f + camY),
                            strokeWidth = 6f
                        )
                    }
                }
            }

            // Draw orange/yellow expanding explosive rings
            for (blast in explosiveBlasts) {
                val alphaVal = (blast.framesLeft / 25f).coerceIn(0f, 1f)
                drawCircle(
                    color = Color(0xFFD84315).copy(alpha = alphaVal * 0.7f),
                    radius = blast.currentRadius,
                    center = Offset(blast.x + camX, blast.y + camY)
                )
                drawCircle(
                    color = Color(0xFFFF9800).copy(alpha = alphaVal * 0.8f),
                    radius = blast.currentRadius * 0.7f,
                    center = Offset(blast.x + camX, blast.y + camY)
                )
                drawCircle(
                    color = Color(0xFFFFEB3B).copy(alpha = alphaVal),
                    radius = blast.currentRadius * 0.4f,
                    center = Offset(blast.x + camX, blast.y + camY)
                )
            }

            // Draw Supersonic Air Support Jet Silhouette flying overhead
            if (airstrikeActive) {
                val jx = airstrikeJetX + camX
                val jy = airstrikeJetY + camY
                
                val cockpit = Offset(jx + 80f, jy)
                val wingL = Offset(jx - 50f, jy - 75f)
                val wingR = Offset(jx - 50f, jy + 75f)
                val tailPt = Offset(jx - 70f, jy)
                
                val planeColor = Color(0xFF607D8B) // Fighter Gray Steel
                // Draw majestic supersonic wings structures
                drawLine(color = planeColor, start = cockpit, end = wingL, strokeWidth = 12f)
                drawLine(color = planeColor, start = cockpit, end = wingR, strokeWidth = 12f)
                drawLine(color = planeColor, start = wingL, end = tailPt, strokeWidth = 12f)
                drawLine(color = planeColor, start = wingR, end = tailPt, strokeWidth = 12f)
                
                // Orange thruster fires!
                drawCircle(
                    color = Color(0xFFE64A19),
                    radius = 18f,
                    center = Offset(jx - 80f, jy)
                )
                drawCircle(
                    color = Color(0xFFFFEB3B),
                    radius = 9f,
                    center = Offset(jx - 78f, jy)
                )
            }

            // Draw creeping zombies (Beautifully detailed, high texture, always visible!)
            for (z in session.zombies) {
                if (z.health <= 0) continue

                // Under our bright daylight setting, zombies are 100% visible at all times!
                val zAngleRad = atan2(z.vy.toDouble(), z.vx.toDouble())
                val zx = z.x + camX
                val zy = z.y + camY

                // 1. Draw zombie rotting torso & shoulders (rotated top-down layout)
                val shLeftX = zx + cos(zAngleRad + Math.PI / 2) * 16f
                val shLeftY = zy + sin(zAngleRad + Math.PI / 2) * 16f
                val shRightX = zx + cos(zAngleRad - Math.PI / 2) * 16f
                val shRightY = zy + sin(zAngleRad - Math.PI / 2) * 16f

                // Decaying tattered shirt line
                drawLine(
                    color = Color(0xFF3E2723), // Rotting brown shirt
                    start = Offset(shLeftX.toFloat(), shLeftY.toFloat()),
                    end = Offset(shRightX.toFloat(), shRightY.toFloat()),
                    strokeWidth = 14f
                )

                // 2. Head circle (vivid moss green)
                drawCircle(
                    color = Color(0xFF4CAF50), // Vibrant zombie green
                    radius = 11f,
                    center = Offset(zx, zy)
                )

                // Head wound / blood stain on head
                drawCircle(
                    color = Color(0xFFD32F2F), 
                    radius = 4f,
                    center = Offset(zx - cos(zAngleRad).toFloat() * 4f, zy - sin(zAngleRad).toFloat() * 4f)
                )

                // 3. Reaching outstretched arms
                val handLX = zx + cos(zAngleRad + 0.3) * 26f
                val handLY = zy + sin(zAngleRad + 0.3) * 26f
                val handRX = zx + cos(zAngleRad - 0.3) * 26f
                val handRY = zy + sin(zAngleRad - 0.3) * 26f

                drawLine(
                    color = Color(0xFF66BB6A), // Slime green arm
                    start = Offset(shLeftX.toFloat(), shLeftY.toFloat()),
                    end = Offset(handLX.toFloat(), handLY.toFloat()),
                    strokeWidth = 6f
                )
                drawLine(
                    color = Color(0xFF66BB6A),
                    start = Offset(shRightX.toFloat(), shRightY.toFloat()),
                    end = Offset(handRX.toFloat(), handRY.toFloat()),
                    strokeWidth = 6f
                )

                // Toxic sharp claws
                drawCircle(
                    color = Color(0xFFFFEB3B), // Yellowed glowing claws
                    radius = 3.5f,
                    center = Offset(handLX.toFloat(), handLY.toFloat())
                )
                drawCircle(
                    color = Color(0xFFFFEB3B),
                    radius = 3.5f,
                    center = Offset(handRX.toFloat(), handRY.toFloat())
                )

                // 4. Glowing red eyes
                val eyeLX = zx + cos(zAngleRad + 0.45) * 6f
                val eyeLY = zy + sin(zAngleRad + 0.45) * 6f
                val eyeRX = zx + cos(zAngleRad - 0.45) * 6f
                val eyeRY = zy + sin(zAngleRad - 0.45) * 6f

                drawCircle(color = Color(0xFFFF1744), radius = 3f, center = Offset(eyeLX.toFloat(), eyeLY.toFloat()))
                drawCircle(color = Color(0xFFFF1744), radius = 3f, center = Offset(eyeRX.toFloat(), eyeRY.toFloat()))

                // 5. Draw health indicators
                drawRect(
                    color = Color(0xFFEF5350).copy(alpha = 0.5f), // background empty bar
                    topLeft = Offset(zx - 20f, zy - 38f),
                    size = Size(40f, 6f)
                )
                drawRect(
                    color = Color(0xFF4CAF50), // health green bar
                    topLeft = Offset(zx - 20f, zy - 38f),
                    size = Size(40f * (z.health / 100f), 6f)
                )
            }

            // Draw player directional flashlight beam cone (yellow arc)
            if (session.flashlightOn && session.flashlightBattery > 0f) {
                drawArc(
                    color = Color(0xFFFFF59D).copy(alpha = 0.18f),
                    startAngle = session.playerAngle - 30f,
                    sweepAngle = 60f,
                    useCenter = true,
                    topLeft = Offset(session.playerX - 380f + camX, session.playerY - 380f + camY),
                    size = Size(760f, 760f)
                )
            }

            // Draw Player character
            val lookRad = Math.toRadians(session.playerAngle.toDouble())
            val px = session.playerX + camX
            val py = session.playerY + camY

            // Kinematic axes
            val cosLook = cos(lookRad).toFloat()
            val sinLook = sin(lookRad).toFloat()
            val cosOrtho = cos(lookRad + Math.PI / 2).toFloat()
            val sinOrtho = sin(lookRad + Math.PI / 2).toFloat()

            // 1. Draw Tactical Backpack (Behind the player, offset in opposite direction of look angle)
            val packSizeW = 18f
            val packSizeH = 12f
            val packX = px - cosLook * 10f
            val packY = py - sinLook * 10f
            
            drawRoundRect(
                color = Color(0xFF33691E), // Olive green backpack
                topLeft = Offset(packX - 9f, packY - 6f),
                size = Size(packSizeW, packSizeH),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
            )
            // Backpack details (straps)
            drawLine(
                color = Color(0xFF1B5E20),
                start = Offset(packX - 6f, packY - 6f),
                end = Offset(packX - 6f, packY + 6f),
                strokeWidth = 2f
            )
            drawLine(
                color = Color(0xFF1B5E20),
                start = Offset(packX + 6f, packY - 6f),
                end = Offset(packX + 6f, packY + 6f),
                strokeWidth = 2f
            )

            // 2. Draw Torso shoulders (rotated flak jacket military look with camo vest details)
            val leftShoulderX = px + cosOrtho * 18f
            val leftShoulderY = py + sinOrtho * 18f
            val rightShoulderX = px - cosOrtho * 18f
            val rightShoulderY = py - sinOrtho * 18f

            val baseSkinColor = when (session.skinName) {
                "Stealth Recon" -> Color(0xFF1A237E) // Tactical Navy
                "Cyber Commando" -> Color(0xFFBF360C) // Cyber Crimson
                "Hazmat Survivor" -> Color(0xFFEF6C00) // Hazard Warning Orange
                else -> Color(0xFF2E7D32) // Forest Ranger
            }

            // Draw military shoulder width line representing flak armor body
            drawLine(
                color = baseSkinColor,
                start = Offset(leftShoulderX, leftShoulderY),
                end = Offset(rightShoulderX, rightShoulderY),
                strokeWidth = 16f
            )
            // Draw secondary dark armor backing plate representing the tactical plate carrier
            drawLine(
                color = Color(0xFF212121), // Charcoal tactical bulletproof plate
                start = Offset(px + cosOrtho * 12f, py + sinOrtho * 12f),
                end = Offset(px - cosOrtho * 12f, py - sinOrtho * 12f),
                strokeWidth = 18f
            )
            // Chest ammo pouches (pouch details on vest)
            val pouchX = px + cosLook * 6f
            val pouchY = py + sinLook * 6f
            drawCircle(
                color = Color(0xFF3E2723), // Ammo leather pocket
                radius = 3.5f,
                center = Offset(pouchX + cosOrtho * 5f, pouchY + sinOrtho * 5f)
            )
            drawCircle(
                color = Color(0xFF3E2723), // Ammo pocket 2
                radius = 3.5f,
                center = Offset(pouchX - cosOrtho * 5f, pouchY - sinOrtho * 5f)
            )

            // 3. Head & Helmet on center
            // Helmet base
            drawCircle(
                color = Color(0xFF37474F), // Slate combat helmet
                radius = 11.5f,
                center = Offset(px, py)
            )
            // Helmet shadow rim
            drawCircle(
                color = Color.Black.copy(alpha = 0.4f),
                radius = 12f,
                center = Offset(px, py),
                style = Stroke(width = 1.5f)
            )
            // Active tactical goggles/visor looking forward
            val visorX = px + cosLook * 7.5f
            val visorY = py + sinLook * 7.5f
            val visorLeftX = visorX + cosOrtho * 6f
            val visorLeftY = visorY + sinOrtho * 6f
            val visorRightX = visorX - cosOrtho * 6f
            val visorRightY = visorY - sinOrtho * 6f

            // Visor line with intense neon tech glow (e.g., Cyan style)
            val visorGlowColor = when (session.skinName) {
                "Stealth Recon" -> Color(0xFF00E5FF) // Cyber Cyan
                "Cyber Commando" -> Color(0xFFFF1744) // Laser Red
                "Hazmat Survivor" -> Color(0xFFEEFF41) // Lime yellow
                else -> Color(0xFF00E676) // Toxic green
            }
            // Draw background visor strap
            drawLine(
                color = Color.Black,
                start = Offset(visorLeftX, visorLeftY),
                end = Offset(visorRightX, visorRightY),
                strokeWidth = 4.5f
            )
            // Draw neon glowing glass bar
            drawLine(
                color = visorGlowColor,
                start = Offset(visorLeftX + cosLook * 1f, visorLeftY + sinLook * 1f),
                end = Offset(visorRightX + cosLook * 1f, visorRightY + sinLook * 1f),
                strokeWidth = 2.5f
            )

            // 4. Tactical Combat Gloves representing hands
            val handLeftX = px + cos(lookRad + 0.35f).toFloat() * 24f
            val handLeftY = py + sin(lookRad + 0.35f).toFloat() * 24f
            val handRightX = px + cos(lookRad - 0.35f).toFloat() * 24f
            val handRightY = py + sin(lookRad - 0.35f).toFloat() * 24f

            // Inner soldier hand details (Glove primary base)
            drawCircle(
                color = Color(0xFF263238), // Dark tactical gloves
                radius = 5f,
                center = Offset(handLeftX, handLeftY)
            )
            drawCircle(
                color = Color(0xFF263238),
                radius = 5f,
                center = Offset(handRightX, handRightY)
            )
            // Knuckle guards (highlight color)
            drawCircle(
                color = baseSkinColor, // highlight matching vest theme
                radius = 2.2f,
                center = Offset(handLeftX, handLeftY)
            )
            drawCircle(
                color = baseSkinColor,
                radius = 2.2f,
                center = Offset(handRightX, handRightY)
            )

            // 5. Weapon Drawing with stunning realistic models
            val weaponLength = when (session.currentWeapon) {
                "Pistol" -> 16f
                "Shotgun" -> 27f
                "Rifle" -> 36f
                "RPG" -> 44f
                else -> 22f // Air Support designator beacon device
            }
            val weaponWidth = when (session.currentWeapon) {
                "Pistol" -> 3.5f
                "Shotgun" -> 6.5f
                "Rifle" -> 5f
                "RPG" -> 8f
                else -> 4f
            }

            val gunStartX = px + cosLook * 12f
            val gunStartY = py + sinLook * 12f
            val gunEndX = px + cosLook * (12f + weaponLength)
            val gunEndY = py + sinLook * (12f + weaponLength)

            when (session.currentWeapon) {
                "Pistol" -> {
                    // Pistol Steel frame
                    drawLine(
                        color = Color(0xFF37474F), // gunmetal
                        start = Offset(gunStartX, gunStartY),
                        end = Offset(gunEndX, gunEndY),
                        strokeWidth = weaponWidth
                    )
                    // Slide chamber highlight (silver)
                    val chamberX = gunStartX + cosLook * 6f
                    val chamberY = gunStartY + sinLook * 6f
                    drawLine(
                        color = Color(0xFFECEFF1),
                        start = Offset(chamberX, chamberY),
                        end = Offset(gunEndX - cosLook * 3f, gunEndY - sinLook * 3f),
                        strokeWidth = 1.8f
                    )
                }
                "Shotgun" -> {
                    // Wood stock/pump slider
                    val woodStartX = gunStartX + cosLook * 2f
                    val woodStartY = gunStartY + sinLook * 2f
                    val woodEndX = gunStartX + cosLook * 14f
                    val woodEndY = gunStartY + sinLook * 14f
                    drawLine(
                        color = Color(0xFF8D6E63), // rich premium wood look
                        start = Offset(woodStartX, woodStartY),
                        end = Offset(woodEndX, woodEndY),
                        strokeWidth = 7.5f
                    )
                    // Double Steel Barrels
                    drawLine(
                        color = Color(0xFF212121),
                        start = Offset(woodEndX, woodEndY),
                        end = Offset(gunEndX, gunEndY),
                        strokeWidth = weaponWidth
                    )
                    // Sight tip dot
                    drawCircle(color = Color.Yellow, radius = 2f, center = Offset(gunEndX, gunEndY))
                }
                "Rifle" -> {
                    // M4/Kala stock & tactical frame
                    drawLine(
                        color = Color(0xFF212121), // matte black rifle
                        start = Offset(gunStartX, gunStartY),
                        end = Offset(gunEndX, gunEndY),
                        strokeWidth = weaponWidth
                    )
                    // Camouflage weapon wrap
                    drawLine(
                        color = baseSkinColor.copy(alpha = 0.7f),
                        start = Offset(gunStartX + cosLook * 4f, gunStartY + sinLook * 4f),
                        end = Offset(gunStartX + cosLook * 18f, gunStartY + sinLook * 18f),
                        strokeWidth = 4.2f
                    )
                    // Silencer/Muzzle brake tip
                    drawLine(
                        color = Color(0xFF78909C), // gun steel silencer
                        start = Offset(gunEndX - cosLook * 5f, gunEndY - sinLook * 5f),
                        end = Offset(gunEndX, gunEndY),
                        strokeWidth = 3f
                    )
                }
                "RPG" -> {
                    // Launcher tube (metallic with wooden heat shield wraps)
                    drawLine(
                        color = Color(0xFF455A64), // dark metal launcher
                        start = Offset(gunStartX, gunStartY),
                        end = Offset(gunEndX, gunEndY),
                        strokeWidth = 5.5f
                    )
                    // Brown wooden insulation shielding center wrap
                    val insulStartX = gunStartX + cosLook * 8f
                    val insulStartY = gunStartY + sinLook * 8f
                    val insulEndX = gunStartX + cosLook * 22f
                    val insulEndY = gunStartY + sinLook * 22f
                    drawLine(
                        color = Color(0xFF5D4037), // rich wood heat shield
                        start = Offset(insulStartX, insulStartY),
                        end = Offset(insulEndX, insulEndY),
                        strokeWidth = 8f
                    )
                    // Trigger pistol grip on RPG
                    drawLine(
                        color = Color.Black,
                        start = Offset(insulStartX + cosLook * 3f, insulStartY + sinLook * 3f),
                        end = Offset(insulStartX + cosLook * 3f - cosOrtho * 6f, insulStartY + sinLook * 3f - sinOrtho * 6f),
                        strokeWidth = 3.5f
                    )
                    // Conical rocket tip sitting inside launcher nose!
                    val rocketNoseX = gunEndX + cosLook * 6f
                    val rocketNoseY = gunEndY + sinLook * 6f
                    // Draw rocket body (olive green with bright yellow toxic bands!)
                    drawLine(
                        color = Color(0xFF2E7D32), // rocket body green
                        start = Offset(gunEndX, gunEndY),
                        end = Offset(rocketNoseX, rocketNoseY),
                        strokeWidth = 8.5f
                    )
                    // Yellow highlight band on the rocket
                    drawCircle(color = Color.Yellow, radius = 4f, center = Offset(gunEndX + cosLook * 3f, gunEndY + sinLook * 3f))
                    // Red detonator nose tip
                    drawCircle(color = Color.Red, radius = 2.5f, center = Offset(rocketNoseX, rocketNoseY))
                }
                else -> { // Air Support designator tablet beacon
                    drawLine(
                        color = Color(0xFF37474F),
                        start = Offset(gunStartX, gunStartY),
                        end = Offset(gunEndX, gunEndY),
                        strokeWidth = weaponWidth
                    )
                    // Pulsing blue designator screen indicator
                    val blinkSec = (System.currentTimeMillis() / 250) % 2 == 0L
                    drawCircle(
                        color = if (blinkSec) Color(0xFF29B6F6) else Color(0xFF0288D1),
                        radius = 3.5f,
                        center = Offset(gunEndX, gunEndY)
                    )
                }
            }

            // 5b. High-fidelity fiery Muzzle Flash & Spark Burst (Real-time dynamic glow)
            val isFiring = System.currentTimeMillis() - lastFireTime < 80
            if (isFiring && session.currentWeapon != "Air Support") {
                val lashRad = Math.toRadians(activeAimAngle.toDouble())
                val flashX = px + cos(lashRad).toFloat() * (12f + weaponLength)
                val flashY = py + sin(lashRad).toFloat() * (12f + weaponLength)

                // Outer blazing impact circle (expanding amber-orange thermal ring)
                drawCircle(
                    color = Color(0xFFFF3D00).copy(alpha = 0.85f),
                    radius = 17f,
                    center = Offset(flashX, flashY)
                )
                // Mid thermal layer
                drawCircle(
                    color = Color(0xFFFFAB00),
                    radius = 11f,
                    center = Offset(flashX, flashY)
                )
                // White-hot center ignition spark core
                drawCircle(
                    color = Color.White,
                    radius = 6f,
                    center = Offset(flashX, flashY)
                )

                // Radiating bullet shell sparks flying forward outward
                val spark1X = flashX + cos(lashRad + 0.28).toFloat() * 24f
                val spark1Y = flashY + sin(lashRad + 0.28).toFloat() * 24f
                drawLine(
                    color = Color(0xFFFFD700),
                    start = Offset(flashX, flashY),
                    end = Offset(spark1X, spark1Y),
                    strokeWidth = 2.5f
                )

                val spark2X = flashX + cos(lashRad - 0.28).toFloat() * 24f
                val spark2Y = flashY + sin(lashRad - 0.28).toFloat() * 24f
                drawLine(
                    color = Color(0xFFFFD700),
                    start = Offset(flashX, flashY),
                    end = Offset(spark2X, spark2Y),
                    strokeWidth = 2.5f
                )

                // Extra long muzzle blast line
                val blastEndX = flashX + cos(lashRad).toFloat() * 15f
                val blastEndY = flashY + sin(lashRad).toFloat() * 15f
                drawLine(
                    color = Color.White,
                    start = Offset(flashX, flashY),
                    end = Offset(blastEndX, blastEndY),
                    strokeWidth = 3f
                )
            }

            // 6. Draw Tactical Neon Laser Aiming Sight
            val angleRad = Math.toRadians(session.playerAngle.toDouble())
            val laserColor = when (session.skinName) {
                "Stealth Recon" -> Color(0xFF00E5FF) // Cyan laser
                "Cyber Commando" -> Color(0xFFFF1744) // Intense laser red
                "Hazmat Survivor" -> Color(0xFFEEFF41) // Lime yellow
                else -> Color(0xFF00E676) // Toxic Neon green
            }
            // Double line drawing representing real volumetric laser beams!
            // First: Thicker semi-transparent laser flare
            drawLine(
                color = laserColor.copy(alpha = 0.16f),
                start = Offset(px, py),
                end = Offset(
                    (session.playerX + cos(angleRad) * 150f).toFloat() + camX,
                    (session.playerY + sin(angleRad) * 150f).toFloat() + camY
                ),
                strokeWidth = 6f
            )
            // Second: Ultra-thin high-intensity bright core solid laser core line
            drawLine(
                color = Color.White.copy(alpha = 0.85f),
                start = Offset(px, py),
                end = Offset(
                    (session.playerX + cos(angleRad) * 150f).toFloat() + camX,
                    (session.playerY + sin(angleRad) * 150f).toFloat() + camY
                ),
                strokeWidth = 1.5f
            )

            drawContext.canvas.restore()
        }

        // --- ON-SCREEN INTERACTIVE TACTICAL GAMEPADS & LABELS ---

        // Top Horizontal HUD Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .windowInsetsPadding(WindowInsets.statusBars),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            // Top-Left: Custom Polish Soldier Vitals layout (Exactly like COD Zombies screenshot!)
            Column(
                modifier = Modifier
                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
                    .border(1.5.dp, Color(0xFF388E3C).copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                    .padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Soldier Name & profile blue indicator
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Back To Lobby trigger icon
                    IconButton(
                        onClick = { onBackToLobby() },
                        modifier = Modifier
                            .size(34.dp)
                            .background(Color.Red.copy(alpha = 0.15f), CircleShape)
                            .border(1.dp, Color.Red, CircleShape)
                    ) {
                        Icon(Icons.Default.ExitToApp, "Exit Mission", tint = Color.Red, modifier = Modifier.size(16.dp))
                    }

                    // Rounded blue indicator representing the soldier icon from screenshot
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .background(Color(0xFF29B6F6), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "👤",
                            fontSize = 11.sp,
                            color = Color.White
                        )
                    }

                    Text(
                        text = if (language == GameLanguage.PERSIAN) "سرباز حسین حمیدی" else "Soldier Hossein Hamidi",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                // Health Row: "جان: [Progress] [Numeric]"
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = if (language == GameLanguage.PERSIAN) "جان:" else "LIFE:",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )

                    // Green Pill Bar from the screenshot!
                    Box(
                        modifier = Modifier
                            .size(width = 140.dp, height = 18.dp)
                            .background(Color(0xFF1E272C), RoundedCornerShape(4.dp))
                            .border(1.5.dp, Color.Black, RoundedCornerShape(4.dp))
                    ) {
                        // Sliding active green zone
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(session.playerHealth / 100f)
                                .background(Color(0xFF4CAF50), RoundedCornerShape(4.dp))
                        )
                        
                        // Centered text label
                        Text(
                            text = "${session.playerHealth.toInt()} / 100",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }
                }

                // Small battery charge rate bar
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "🔋",
                        fontSize = 11.sp
                    )
                    Box(
                        modifier = Modifier
                            .size(width = 80.dp, height = 6.dp)
                            .background(Color.DarkGray, RoundedCornerShape(1f))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(session.flashlightBattery / 100f)
                                .background(Color.Yellow, RoundedCornerShape(1f))
                        )
                    }
                }
            }

            // Top-Right: Points & Kills tracker AND Custom Weapon Dashboard Panel!
            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Neon bold points label "امتیاز 500"
                Text(
                    text = if (language == GameLanguage.PERSIAN) "امتیاز ${session.score}" else "SCORE ${session.score}",
                    color = Color(0xFF00E676), // Intense green neon
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp
                )

                // Dispatch metric label "نابودی: ۰"
                val killsCount = session.score / 200
                Text(
                    text = if (language == GameLanguage.PERSIAN) "نابودی: $killsCount" else "KILLED: $killsCount",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Custom tactical Weapon Display Frame matching the second screenshot!
                Row(
                    modifier = Modifier
                        .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(6.dp))
                        .border(1.5.dp, Color(0xFFE53935), RoundedCornerShape(6.dp)) // Red frame border
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(horizontalAlignment = Alignment.Start) {
                        // Local weapon translated label
                        val weaponLabel = when (session.currentWeapon) {
                            "Pistol" -> if (language == GameLanguage.PERSIAN) "کلت ۱۹۱۱" else "COLT 1911"
                            "Shotgun" -> if (language == GameLanguage.PERSIAN) "تفنگ شاتگان" else "PUMP SHOTGUN"
                            "Rifle" -> if (language == GameLanguage.PERSIAN) "کلاشنیکف M4" else "KALA M4"
                            else -> if (language == GameLanguage.PERSIAN) "آر پی جی ۷" else "RPG-7 HERO"
                        }
                        
                        Text(
                            text = weaponLabel,
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        
                        Spacer(modifier = Modifier.height(2.dp))
                        
                        // Fake capacity divider like "5 / 80"
                        Text(
                            text = "${session.ammo} / 80",
                            color = Color(0xFFE53935),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    // Dynamic stylized gun outline schematic representation on the side
                    val gunGraphic = when (session.currentWeapon) {
                        "Pistol" -> "┳━─"
                        "Shotgun" -> "┳┳━══"
                        else -> "┳┳━═──"
                    }
                    Text(
                        text = gunGraphic,
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        // Independent Top-Center floating game alerts / narrator messages that will never squish other HUD elements!
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 95.dp) // Pushed elegantly below the HUD bar
                .windowInsetsPadding(WindowInsets.statusBars),
            contentAlignment = Alignment.TopCenter
        ) {
            androidx.compose.animation.AnimatedVisibility(
                visible = gameMessage != null,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DeadzoneSurface.copy(alpha = 0.95f)),
                    modifier = Modifier.border(1.5.dp, Color(0xFFE53935), RoundedCornerShape(4.dp))
                ) {
                    Text(
                        text = gameMessage ?: "",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        lineHeight = 14.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }
        }
        LaunchedEffect(gameMessage) {
            if (gameMessage != null) {
                delay(2800)
                gameMessage = null
            }
        }

        // Left-Side & Right-Side Thumb Anchors layered over the Canvas
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Bottom-Left Section (Movement joystick with blood-red COD Zombies wave count overlay)
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .width(180.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Wave Counter directly matching the classic COD Zombies corner layout!
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(bottom = 4.dp)
                ) {
                    Text(
                        text = if (language == GameLanguage.PERSIAN) "مـوج" else "WAVE",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFF5722), // Scary blood red
                        letterSpacing = 1.5.sp
                    )
                    Text(
                        text = session.currentWave.toString(),
                        fontSize = 48.sp,
                        fontWeight = FontWeight.Black,
                        color = Color(0xFFFF3D00), // Huge stylized blood-red count
                        modifier = Modifier.offset(y = (-4).dp)
                    )
                }

                // 360-degree Multidirectional Movement virtual controller with neon blue glow
                Box(
                    modifier = Modifier
                        .size(130.dp)
                        .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                        .border(2.5.dp, Color(0xFF29B6F6).copy(alpha = 0.8f), CircleShape), // Radiant Cyan/Blue ring
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragStart = { },
                                    onDragEnd = {
                                        joystickOffsetX = 0f
                                        joystickOffsetY = 0f
                                        activeMoveX = 0f
                                        activeMoveY = 0f
                                    },
                                    onDragCancel = {
                                        joystickOffsetX = 0f
                                        joystickOffsetY = 0f
                                        activeMoveX = 0f
                                        activeMoveY = 0f
                                    },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        val nextX = joystickOffsetX + dragAmount.x
                                        val nextY = joystickOffsetY + dragAmount.y
                                        val dist = sqrt(nextX * nextX + nextY * nextY)
                                        val maxRadiusPx = 150f
                                        if (dist <= maxRadiusPx) {
                                            joystickOffsetX = nextX
                                            joystickOffsetY = nextY
                                        } else {
                                            joystickOffsetX = (nextX / dist) * maxRadiusPx
                                            joystickOffsetY = (nextY / dist) * maxRadiusPx
                                        }
                                        
                                        // Process angle and vector velocity
                                        val dragRad = atan2(joystickOffsetY.toDouble(), joystickOffsetX.toDouble())
                                        val speedMultiplier = if (runningMode) 5.2f else 2.2f
                                        activeMoveX = (cos(dragRad) * speedMultiplier).toFloat()
                                        activeMoveY = (sin(dragRad) * speedMultiplier).toFloat()
                                        
                                        // Orient character angle to match movement direc
                                        session.playerAngle = Math.toDegrees(dragRad).toFloat()
                                        activeAimAngle = session.playerAngle
                                    }
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        // Joystick background concentric ring details
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawCircle(
                                color = Color(0xFF29B6F6).copy(alpha = 0.08f),
                                radius = size.width / 2f
                            )
                            drawCircle(
                                color = Color(0xFF29B6F6).copy(alpha = 0.15f),
                                radius = size.width / 4f,
                                style = Stroke(width = 1.5f)
                            )
                            // Cross lines
                            drawLine(
                                color = Color(0xFF29B6F6).copy(alpha = 0.25f),
                                start = Offset(0f, size.height / 2f),
                                end = Offset(size.width, size.height / 2f)
                            )
                            drawLine(
                                color = Color(0xFF29B6F6).copy(alpha = 0.25f),
                                start = Offset(size.width / 2f, 0f),
                                end = Offset(size.width / 2f, size.height)
                            )
                        }

                        // Radiant Cyan Active Knob Thumb Handle
                        Box(
                            modifier = Modifier
                                .offset(
                                    x = (joystickOffsetX / 2.8f).dp,
                                    y = (joystickOffsetY / 2.8f).dp
                                )
                                .size(48.dp)
                                .background(
                                    brush = androidx.compose.ui.graphics.Brush.radialGradient(
                                        colors = listOf(Color(0xFF81D4FA), Color(0xFF0288D1))
                                    ),
                                    shape = CircleShape
                                )
                                .border(2.dp, Color.White, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .background(Color.Black, CircleShape)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Interactive Sprint controller toggler
                Button(
                    onClick = { runningMode = !runningMode },
                    colors = ButtonDefaults.buttonColors(containerColor = if (runningMode) Color(0xFF29B6F6) else Color.DarkGray),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                    modifier = Modifier
                        .height(30.dp)
                        .border(1.dp, Color.White.copy(alpha = 0.6f), RoundedCornerShape(15.dp))
                ) {
                    Text(
                        text = if (runningMode) "حالت دو سریع (RUN)" else "حالت آهسته (WALK)",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (runningMode) Color.Black else Color.White
                    )
                }
            }

            // Bottom-Right Section (Right-Side Anchors for Right-Thumb)
            Column(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .width(220.dp),
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 1. Quick Weapon selection row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.65f), RoundedCornerShape(6.dp))
                        .border(1.2.dp, Color(0xFFFF5722).copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val weaponsList = listOf("Pistol", "Shotgun", "Rifle", "RPG", "Air Support")
                    weaponsList.forEach { w ->
                        val isSelected = session.currentWeapon == w
                        val isEnglish = language != GameLanguage.PERSIAN
                        val label = when(w) {
                            "Pistol" -> "PST کلت"
                            "Shotgun" -> "SHTG شاتفن"
                            "Rifle" -> "RFL کلاش"
                            "RPG" -> "RPG راکت"
                            else -> "AIR بمباران"
                        }
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(1.dp)
                                .background(if (isSelected) Color(0xFFFF5722).copy(alpha = 0.25f) else Color.Transparent, RoundedCornerShape(4.dp))
                                .border(1.dp, if (isSelected) Color(0xFFFF5722) else Color.DarkGray, RoundedCornerShape(4.dp))
                                .clickable {
                                    if (w == "Pistol") {
                                        session.currentWeapon = "Pistol"
                                        gameMessage = if (isEnglish) "EQUIPPED PISTOL" else "کلت سازمانی با موفقیت مجهز شد!"
                                    } else if (w == "Shotgun") {
                                        if (session.cashEarned >= 300 || session.currentWeapon == "Shotgun") {
                                            if (session.currentWeapon != "Shotgun") session.cashEarned -= 300
                                            session.currentWeapon = "Shotgun"
                                            gameMessage = if (isEnglish) "EQUIPPED SHOTGUN!" else "شاتگان نیمه خودکار مجهز شد!"
                                        } else {
                                            gameMessage = if (isEnglish) "NEED $300!" else "شاتگان نیاز به ۳۰۰ سکه دارد!"
                                        }
                                    } else if (w == "Rifle") {
                                        if (session.cashEarned >= 500 || session.currentWeapon == "Rifle") {
                                            if (session.currentWeapon != "Rifle") session.cashEarned -= 500
                                            session.currentWeapon = "Rifle"
                                            gameMessage = if (isEnglish) "EQUIPPED RIFLE!" else "کلاشنیکف M4 مجهز شد!"
                                        } else {
                                            gameMessage = if (isEnglish) "NEED $500!" else "کلاشنیکف نیاز به ۵۰۰ سکه دارد!"
                                        }
                                    } else if (w == "RPG") {
                                        if (session.cashEarned >= 1100 || session.currentWeapon == "RPG") {
                                            if (session.currentWeapon != "RPG") session.cashEarned -= 1100
                                            session.currentWeapon = "RPG"
                                            gameMessage = if (isEnglish) "EQUIPPED RPG-7!" else "راکت انداز سنگین آر پی جی ۷ مجهز شد!"
                                        } else {
                                            gameMessage = if (isEnglish) "NEED $1100!" else "آر پی جی نیاز به ۱۱۰۰ سکه دارد!"
                                        }
                                    } else if (w == "Air Support") {
                                        if (session.cashEarned >= 2400 || session.currentWeapon == "Air Support") {
                                            if (session.currentWeapon != "Air Support") session.cashEarned -= 2400
                                            session.currentWeapon = "Air Support"
                                            gameMessage = if (isEnglish) "EQUIPPED AIRSTRIKE!" else "سیستم بمباران هوایی مجهز شد!"
                                        } else {
                                            gameMessage = if (isEnglish) "NEED $2400!" else "حملات هوایی نیاز به ۲۴۰۰ سکه دارد!"
                                        }
                                    }
                                }
                                .padding(vertical = 5.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color(0xFFFF5722) else Color.White,
                                maxLines = 1
                            )
                        }
                    }
                }

                // 2. Dual-Analog Aim Controller & Main Arcade buttons arranged neatly
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Tactile 360-degree AIM WHEEL on the left side of the right-thumb pad
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .background(Color.Black.copy(alpha = 0.5f), CircleShape)
                            .border(2.dp, Color(0xFFFF3D00).copy(alpha = 0.8f), CircleShape), // Radiant Crimson Aiming scope ring
                        contentAlignment = Alignment.Center
                    ) {
                        var aimDragX by remember { mutableStateOf(0f) }
                        var aimDragY by remember { mutableStateOf(0f) }

                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .pointerInput(Unit) {
                                    detectDragGestures(
                                        onDragStart = { 
                                            isAiming = true
                                        },
                                        onDragEnd = {
                                            aimDragX = 0f
                                            aimDragY = 0f
                                            isAiming = false
                                        },
                                        onDragCancel = {
                                            aimDragX = 0f
                                            aimDragY = 0f
                                            isAiming = false
                                        },
                                        onDrag = { change, dragAmount ->
                                            change.consume()
                                            aimDragX += dragAmount.x
                                            aimDragY += dragAmount.y
                                            
                                            val dist = sqrt(aimDragX * aimDragX + aimDragY * aimDragY)
                                            if (dist > 10f) {
                                                val rad = atan2(aimDragY.toDouble(), aimDragX.toDouble())
                                                activeAimAngle = Math.toDegrees(rad).toFloat()
                                                session.playerAngle = activeAimAngle
                                            }
                                            isAiming = true
                                        }
                                    )
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                // Draw targeting crosshair lines
                                drawCircle(Color(0xFFFF3D00).copy(alpha = 0.05f))
                                drawLine(
                                    color = Color(0xFFFF3D00).copy(alpha = 0.3f),
                                    start = Offset(0f, size.height / 2f),
                                    end = Offset(size.width, size.height / 2f),
                                    strokeWidth = 1f
                                )
                                drawLine(
                                    color = Color(0xFFFF3D00).copy(alpha = 0.3f),
                                    start = Offset(size.width / 2f, 0f),
                                    end = Offset(size.width / 2f, size.height),
                                    strokeWidth = 1f
                                )
                            }
                            
                            // Glowing Scope Indicator
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .background(Color(0xFFFF3D00).copy(alpha = 0.3f), CircleShape)
                                    .border(1.5.dp, Color.White, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("🎯", fontSize = 10.sp)
                            }
                        }
                    }

                    // Large circular arcade actions stack
                    Column(
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Flashlight toggle bubble
                            Button(
                                onClick = { session.flashlightOn = !session.flashlightOn },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (session.flashlightOn) Color.Yellow else Color.DarkGray
                                ),
                                shape = CircleShape,
                                contentPadding = PaddingValues(0.dp),
                                modifier = Modifier
                                    .size(42.dp)
                                    .border(1.dp, Color.White, CircleShape)
                            ) {
                                Text(if (session.flashlightOn) "🔦" else "🕶️", fontSize = 16.sp)
                            }

                            // Reload/Buy Ammo Button bubble
                            Button(
                                onClick = {
                                    if (session.cashEarned >= 50) {
                                        session.cashEarned -= 50
                                        session.ammo += 12
                                        gameMessage = if (language == GameLanguage.PERSIAN) "خشاب پر شد! (۱۲+ تیر)" else "RELOADED! +12 AMMO"
                                    } else {
                                        gameMessage = if (language == GameLanguage.PERSIAN) "نیاز به ۵۰ سکه برای خرید مهمات!" else "NEED $50 CASH!"
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD84315)),
                                shape = CircleShape,
                                contentPadding = PaddingValues(0.dp),
                                modifier = Modifier
                                    .size(44.dp)
                                    .border(1.dp, Color.White, CircleShape)
                            ) {
                                Text(
                                    text = if (language == GameLanguage.PERSIAN) "خشاب" else "RLD",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Universal Proximity Interaction Button bubble (تعمیر، خرید، خروج، درب۱، درب۲)
                            val distToGenerator = calculateDistance(session.playerX, session.playerY, session.generatorX, session.generatorY)
                            val distToBarricade = calculateDistance(session.playerX, session.playerY, 900f, session.playerY)
                            val distToDoor2 = calculateDistance(session.playerX, session.playerY, 1450f, session.playerY)
                            val distToBuy = calculateDistance(session.playerX, session.playerY, session.buyStationX, session.buyStationY)
                            val distToGate = calculateDistance(session.playerX, session.playerY, session.gateX, session.gateY)

                            val contextInteractive = when {
                                distToGenerator < 100f && !session.powerGeneratorRepaired -> if (language == GameLanguage.PERSIAN) "تعمیر" else "FIX"
                                distToBarricade < 100f && !session.doorBarricadeCleared -> if (language == GameLanguage.PERSIAN) "درب۱" else "DOOR1"
                                distToDoor2 < 100f && !door2Unlocked && session.doorBarricadeCleared -> if (language == GameLanguage.PERSIAN) "درب۲" else "DOOR2"
                                distToBuy < 100f -> if (language == GameLanguage.PERSIAN) "خرید" else "SHOP"
                                distToGate < 100f -> if (language == GameLanguage.PERSIAN) "خروج" else "ESCAPE"
                                else -> null
                            }
                            
                            Button(
                                onClick = {
                                    when {
                                        distToGenerator < 100f && !session.powerGeneratorRepaired -> {
                                            session.powerGeneratorRepaired = true
                                            session.score += 500
                                            gameMessage = if (language == GameLanguage.PERSIAN) "ژنراتور برق احیا شد! به خروجی پناه ببرید!" else "Generator Repaired! Head to Exit!"
                                        }
                                        distToBarricade < 100f && !session.doorBarricadeCleared -> {
                                            if (session.cashEarned >= 500) {
                                                session.cashEarned -= 500
                                                session.doorBarricadeCleared = true
                                                gameMessage = if (language == GameLanguage.PERSIAN) "درب خانه باغچه با ۵۰۰ سکه باز شد!" else "Door 1 Unlocked!"
                                            } else {
                                                gameMessage = if (language == GameLanguage.PERSIAN) "برای باز کردن درب خانه باغچه به ۵۰۰ سکه نیاز دارید!" else "Need 500 cash for Door 1!"
                                            }
                                        }
                                        distToDoor2 < 100f && !door2Unlocked && session.doorBarricadeCleared -> {
                                            if (session.cashEarned >= 1500) {
                                                session.cashEarned -= 1500
                                                door2Unlocked = true
                                                gameMessage = if (language == GameLanguage.PERSIAN) "درب بخش ژنراتور با ۱۵۰۰ سکه باز شد!" else "Door 2 Unlocked!"
                                            } else {
                                                gameMessage = if (language == GameLanguage.PERSIAN) "برای باز کردن بخش ژنراتور به ۱۵۰۰ سکه نیاز دارید!" else "Need 1500 cash for Door 2!"
                                            }
                                        }
                                        distToBuy < 100f -> {
                                            isShoppingOpened = true
                                        }
                                        distToGate < 100f -> {
                                            if (session.powerGeneratorRepaired) {
                                                session.isVictory = true
                                                onGameResult(session.score / 200 + 10, session.score + 1000, session.cashEarned + 150)
                                            } else {
                                                gameMessage = if (language == GameLanguage.PERSIAN) "ابتدا ژنراتور خاموش را در انتهای سالن تعمیر و روشن کنید!" else "Repair generator first!"
                                            }
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (contextInteractive != null) Color(0xFF00E676) else Color.DarkGray
                                ),
                                enabled = contextInteractive != null,
                                shape = CircleShape,
                                contentPadding = PaddingValues(0.dp),
                                modifier = Modifier
                                    .size(46.dp)
                                    .border(1.5.dp, if (contextInteractive != null) Color.White else Color.Transparent, CircleShape)
                            ) {
                                Text(
                                    text = contextInteractive ?: "تعامل",
                                    color = if (contextInteractive != null) Color.Black else Color.LightGray,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Armory Buy station dialog
        if (isShoppingOpened) {
            AlertDialog(
                onDismissRequest = { isShoppingOpened = false },
                title = { Text(text = "پایانه خرید تسلیحات و پشتیبانی", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(text = "سکه یا بودجه فعلی شما: ${session.cashEarned} سکه", color = DeadzonePrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))
                        
                        // 1. Ammunition purchases
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "خرید خشاب مهمات (+۱۲ تیر)", fontSize = 12.sp, color = Color.White)
                            Button(
                                onClick = {
                                    if (session.cashEarned >= 50) {
                                        session.cashEarned -= 50
                                        session.ammo += 12
                                        gameMessage = "خرید خشاب با موفقیت انجام شد!"
                                    } else {
                                        gameMessage = "سکه کافی نیست! زامبی‌های بیشتری بکشید."
                                    }
                                    isShoppingOpened = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DeadzoneAccent),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(30.dp).testTag("shop_buy_ammo")
                            ) {
                                Text(text = "۵۰ سکه", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // 2. Shotgun buy
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "شاتگان نیمه خودکار (۳ ساچمه همزمان)", fontSize = 12.sp, color = Color.White)
                            Button(
                                onClick = {
                                    if (session.cashEarned >= 300) {
                                        session.cashEarned -= 300
                                        session.currentWeapon = "Shotgun"
                                        session.ammo += 6
                                        gameMessage = "تفنگ شاتگان مجهز شد!"
                                    } else {
                                        gameMessage = "سکه کافی نیست!"
                                    }
                                    isShoppingOpened = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DeadzoneAccent),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(30.dp).testTag("shop_buy_shotgun")
                            ) {
                                Text(text = "۳۰۰ سکه", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // 3. Rifle buy
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "تفنگ تهاجمی خودکار (+۴۰ درصد قدرت)", fontSize = 12.sp, color = Color.White)
                            Button(
                                onClick = {
                                    if (session.cashEarned >= 500) {
                                        session.cashEarned -= 500
                                        session.currentWeapon = "Rifle"
                                        session.ammo += 24
                                        gameMessage = "تفنگ تهاجمی ام ۴ مجهز شد!"
                                    } else {
                                        gameMessage = "سکه کافی نیست!"
                                    }
                                    isShoppingOpened = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DeadzoneAccent),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(30.dp).testTag("shop_buy_rifle")
                            ) {
                                Text(text = "۵۰۰ سکه", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // 4. RPG buy
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "راکت انداز آر پی جی (انفجار مهیب دوربرد)", fontSize = 12.sp, color = Color.White)
                            Button(
                                onClick = {
                                    if (session.cashEarned >= 1100) {
                                        session.cashEarned -= 1100
                                        session.currentWeapon = "RPG"
                                        session.ammo += 5
                                        gameMessage = "آر پی جی مرگبار مجهز شد!"
                                    } else {
                                        gameMessage = "سکه برای خرید آر پی جی کافی نیست!"
                                    }
                                    isShoppingOpened = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DeadzoneAccent),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(30.dp).testTag("shop_buy_rpg")
                            ) {
                                Text(text = "۱۱۰۰ سکه", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        // 5. Air Support purchase
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "پشتیبانی هوایی بمباران (جت شکاری)", fontSize = 12.sp, color = Color.White)
                            Button(
                                onClick = {
                                    if (session.cashEarned >= 2400) {
                                        session.cashEarned -= 2400
                                        session.currentWeapon = "Air Support"
                                        session.ammo += 2
                                        gameMessage = "سیستم ردیاب پشتیبانی بمباران جت مجهز شد!"
                                    } else {
                                        gameMessage = "سکه برای پشتیبانی هوایی جنگنده کافی نیست!"
                                    }
                                    isShoppingOpened = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DeadzoneAccent),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                modifier = Modifier.height(30.dp).testTag("shop_buy_airstrike")
                            ) {
                                Text(text = "۲۴۰۰ سکه", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = { isShoppingOpened = false }, colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)) {
                        Text(text = "انصراف / خروج")
                    }
                },
                containerColor = DeadzoneSurface,
                modifier = Modifier.border(1.dp, DeadzoneAccent, RoundedCornerShape(8.dp))
            )
        }

        // Game Over and Victory screens overlay
        if (session.isGameOver) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.9f))
                    .testTag("game_over_overlay"),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DeadzoneSurface),
                    modifier = Modifier
                        .width(360.dp)
                        .border(1.dp, DeadzoneTertiary, RoundedCornerShape(8.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = Localization.get("game_gameover", language).uppercase(),
                            color = DeadzoneTertiary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(text = "Final Combat Score: ${session.score} PTS", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(text = "Total Earned Cash: +$${session.cashEarned}", color = Color.LightGray, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(24.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(
                                onClick = { onBackToLobby() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
                            ) {
                                Text(text = Localization.get("game_exit", language), fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }

        if (session.isVictory) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.9f))
                    .testTag("victory_overlay"),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DeadzoneSurface),
                    modifier = Modifier
                        .width(360.dp)
                        .border(1.dp, DeadzonePrimary, RoundedCornerShape(8.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = Localization.get("game_victory", language).uppercase(),
                            color = DeadzonePrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(text = "Mission High Score: ${session.score} PTS", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(text = "Total Earned Cash: +$${session.cashEarned}", color = Color.LightGray, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(24.dp))
                        Button(
                            onClick = { onBackToLobby() },
                            colors = ButtonDefaults.buttonColors(containerColor = DeadzonePrimary)
                        ) {
                            Text(text = Localization.get("game_exit", language), color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
